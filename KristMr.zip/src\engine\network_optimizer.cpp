#include "network_optimizer.hpp"

namespace KristMr {

    std::wstring NetworkOptimizer::GetRegistryBackupFilePath() {
        return GetProgramDataAppDir() + L"\\registry_backup.bin";
    }

    bool NetworkOptimizer::SaveBackup(const RegistryBackupData& data) {
        HANDLE hFile = CreateFileW(
            GetRegistryBackupFilePath().c_str(),
            GENERIC_WRITE,
            0,
            NULL,
            CREATE_ALWAYS,
            FILE_ATTRIBUTE_NORMAL | FILE_FLAG_WRITE_THROUGH,
            NULL
        );
        if (hFile == INVALID_HANDLE_VALUE) return false;

        DWORD written = 0;
        BOOL res = WriteFile(hFile, &data, sizeof(data), &written, NULL);
        CloseHandle(hFile);
        return (res && written == sizeof(data));
    }

    bool NetworkOptimizer::LoadBackup(RegistryBackupData& data) {
        HANDLE hFile = CreateFileW(
            GetRegistryBackupFilePath().c_str(),
            GENERIC_READ,
            FILE_SHARE_READ,
            NULL,
            OPEN_EXISTING,
            FILE_ATTRIBUTE_NORMAL,
            NULL
        );
        if (hFile == INVALID_HANDLE_VALUE) return false;

        DWORD readBytes = 0;
        BOOL res = ReadFile(hFile, &data, sizeof(data), &readBytes, NULL);
        CloseHandle(hFile);
        return (res && readBytes == sizeof(data));
    }

    bool NetworkOptimizer::FlushDnsCache() {
        HMODULE hDnsApi = LoadLibraryW(L"dnsapi.dll");
        if (hDnsApi) {
            pfnDnsFlushResolverCache pfnFlush = reinterpret_cast<pfnDnsFlushResolverCache>(
                GetProcAddress(hDnsApi, "DnsFlushResolverCache")
            );
            if (pfnFlush) {
                BOOL res = pfnFlush();
                FreeLibrary(hDnsApi);
                return (res != FALSE);
            }
            FreeLibrary(hDnsApi);
        }
        return false;
    }

    bool NetworkOptimizer::ApplyNetworkTweaks() {
        const wchar_t* subKey = L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile";
        HKEY hKey = NULL;

        if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, subKey, 0, KEY_READ | KEY_WRITE, &hKey) != ERROR_SUCCESS) {
            return false;
        }

        RegistryBackupData backup = {};
        DWORD val = 0, valSize = sizeof(DWORD), type = REG_DWORD;

        // Бэкап NetworkThrottlingIndex
        if (RegQueryValueExW(hKey, L"NetworkThrottlingIndex", NULL, &type, (LPBYTE)&val, &valSize) == ERROR_SUCCESS) {
            backup.hasNetworkThrottling = true;
            backup.origNetworkThrottling = val;
        }

        // Бэкап SystemResponsiveness
        valSize = sizeof(DWORD);
        if (RegQueryValueExW(hKey, L"SystemResponsiveness", NULL, &type, (LPBYTE)&val, &valSize) == ERROR_SUCCESS) {
            backup.hasSystemResponsiveness = true;
            backup.origSystemResponsiveness = val;
        }

        SaveBackup(backup);

        // Установка оптимальных параметров (0xFFFFFFFF - отключение сетевого троттлинга, 0x0 - максимальный отклик для игр/системы)
        DWORD newThrottle = 0xFFFFFFFF;
        DWORD newResp = 0x00000000;

        RegSetValueExW(hKey, L"NetworkThrottlingIndex", 0, REG_DWORD, (const BYTE*)&newThrottle, sizeof(DWORD));
        RegSetValueExW(hKey, L"SystemResponsiveness", 0, REG_DWORD, (const BYTE*)&newResp, sizeof(DWORD));

        RegCloseKey(hKey);
        return true;
    }

    void NetworkOptimizer::RestoreRegistryTweaks() {
        RegistryBackupData backup = {};
        if (LoadBackup(backup)) {
            const wchar_t* subKey = L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile";
            HKEY hKey = NULL;

            if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, subKey, 0, KEY_WRITE, &hKey) == ERROR_SUCCESS) {
                if (backup.hasNetworkThrottling) {
                    RegSetValueExW(hKey, L"NetworkThrottlingIndex", 0, REG_DWORD, (const BYTE*)&backup.origNetworkThrottling, sizeof(DWORD));
                }
                if (backup.hasSystemResponsiveness) {
                    RegSetValueExW(hKey, L"SystemResponsiveness", 0, REG_DWORD, (const BYTE*)&backup.origSystemResponsiveness, sizeof(DWORD));
                }
                RegCloseKey(hKey);
            }
        }

        // Удаляем backup-файл
        DeleteFileW(GetRegistryBackupFilePath().c_str());
    }

}
