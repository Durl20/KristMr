#pragma once

#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif

#include <windows.h>
#include <windowsx.h>
#include <mmsystem.h>
#include <shellapi.h>
#include <shlobj.h>
#include <shlwapi.h>
#include <taskschd.h>
#include <comdef.h>
#include <powrprof.h>
#include <winhttp.h>
#include <wrl/client.h>
#include <d3d11.h>
#include <dxgi1_3.h>
#include <dcomp.h>
#include <d3dcompiler.h>
#include <aclapi.h>
#include <sddl.h>
#include <ntsecapi.h>

#include <string>
#include <string_view>
#include <vector>
#include <array>
#include <memory>
#include <chrono>
#include <thread>
#include <mutex>
#include <atomic>
#include <unordered_map>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <functional>
#include <cmath>
#include <algorithm>

namespace fs = std::filesystem;
using Microsoft::WRL::ComPtr;

namespace KristMr {

    // Системные константы развертывания
    constexpr const wchar_t* APP_MUTEX_NAME = L"Global\\KristMr_SingleInstance_Mutex";
    constexpr const wchar_t* APP_USER_MODEL_ID = L"KristMr.Core.Monitor";
    constexpr const wchar_t* TASK_NAME = L"KristMr_AutoStart";

    constexpr int WINDOW_WIDTH = 360;
    constexpr int WINDOW_HEIGHT = 540;
    constexpr int CORNER_RADIUS = 18;

    // Цвета интерфейса (RGBA)
    struct ColorRGBA {
        float r, g, b, a;
    };

    inline constexpr ColorRGBA COLOR_AZURE    = { 0.15f, 0.82f, 1.0f, 1.0f }; // Штатный / Hyper (Светящийся циан)
    inline constexpr ColorRGBA COLOR_CRIMSON  = { 1.0f, 0.1f,  0.2f, 1.0f }; // Hard Veto (Алый)
    inline constexpr ColorRGBA COLOR_EMERALD  = { 0.1f, 1.0f,  0.4f, 1.0f }; // Безопасный unlocker (Изумрудный)
    inline constexpr ColorRGBA COLOR_AMBER    = { 1.0f, 0.65f, 0.0f, 1.0f }; // Неизвестная репутация (Янтарный)

    enum class CrystalState {
        Loading,        // Фаза 0: Загрузчик 5 точек
        HyperActive,    // Лазурно-синий
        ThreatDetected, // Алый
        BypassAllowed,  // Изумрудный
        QuarantineAlert // Янтарный
    };

    // Определение недокументированных структур и функций NT Native API
    typedef LONG NTSTATUS;
    #define STATUS_SUCCESS ((NTSTATUS)0x00000000L)

    typedef enum _SYSTEM_INFORMATION_CLASS {
        SystemMemoryListInformation = 80
    } SYSTEM_INFORMATION_CLASS;

    typedef enum _SYSTEM_MEMORY_LIST_COMMAND {
        MemoryCaptureAccessedBits,
        MemoryCaptureAndResetAccessedBits,
        MemoryEmptyWorkingSets,
        MemoryFlushModifiedList,
        MemoryPurgeStandbyList,
        MemoryPurgeLowPriorityStandbyList,
        MemoryCommandMax
    } SYSTEM_MEMORY_LIST_COMMAND;

    typedef NTSTATUS(NTAPI* pfnNtSetTimerResolution)(
        ULONG DesiredResolution,
        BOOLEAN SetResolution,
        PULONG CurrentResolution
    );

    typedef NTSTATUS(NTAPI* pfnNtSetSystemInformation)(
        SYSTEM_INFORMATION_CLASS SystemInformationClass,
        PVOID SystemInformation,
        ULONG SystemInformationLength
    );

    typedef NTSTATUS(NTAPI* pfnNtSetInformationProcess)(
        HANDLE ProcessHandle,
        ULONG ProcessInformationClass,
        PVOID ProcessInformation,
        ULONG ProcessInformationLength
    );

    typedef BOOL(WINAPI* pfnDnsFlushResolverCache)();

    // Вспомогательные пути
    inline std::wstring GetProgramFilesAppDir() {
        wchar_t path[MAX_PATH];
        if (SUCCEEDED(SHGetFolderPathW(NULL, CSIDL_PROGRAM_FILES, NULL, 0, path))) {
            return std::wstring(path) + L"\\KristMr";
        }
        return L"C:\\Program Files\\KristMr";
    }

    inline std::wstring GetProgramDataAppDir() {
        wchar_t path[MAX_PATH];
        if (SUCCEEDED(SHGetFolderPathW(NULL, CSIDL_COMMON_APPDATA, NULL, 0, path))) {
            return std::wstring(path) + L"\\KristMr";
        }
        return L"C:\\ProgramData\\KristMr";
    }

    inline std::wstring GetInstalledExePath() {
        return GetProgramFilesAppDir() + L"\\KristMr.exe";
    }
}
