#pragma once
#include "../common.hpp"

namespace KristMr {

    struct FileValidationResult {
        bool isValid = false;
        bool isReparsePoint = false;
        DWORD numberOfLinks = 0;
        std::wstring finalPath = L"";
        std::wstring errorReason = L"";
    };

    class FileGuard {
    public:
        // Открытие файла с защитой от LPE и symlink/junction
        static HANDLE OpenSafeFile(const std::wstring& path, DWORD desiredAccess, DWORD shareMode, DWORD creationDisposition);

        // Полная валидация безопасности файла по хэндлу
        static FileValidationResult ValidateFileHandle(HANDLE hFile, const std::wstring& expectedPath);

        // Безопасная очистка временных файлов (%TEMP%)
        static void CleanTempJunkSafe();

        // Проверка, является ли путь ссылкой/junction без открытия хэндла
        static bool IsReparsePointPath(const std::wstring& path);
    };

}
