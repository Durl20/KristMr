#include "installer.hpp"
#include <propkey.h>
#include <propvarutil.h>

namespace KristMr {

    bool Installer::IsProcessElevated() {
        HANDLE hToken = NULL;
        if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &hToken)) {
            return false;
        }

        TOKEN_ELEVATION elevation;
        DWORD dwSize = sizeof(TOKEN_ELEVATION);
        BOOL bElevated = FALSE;

        if (GetTokenInformation(hToken, TokenElevation, &elevation, sizeof(elevation), &dwSize)) {
            bElevated = elevation.TokenIsElevated;
        }

        CloseHandle(hToken);
        return bElevated != FALSE;
    }

    bool Installer::IsRunningFromProgramFiles() {
        wchar_t currentExe[MAX_PATH];
        if (GetModuleFileNameW(NULL, currentExe, MAX_PATH) == 0) return false;

        std::wstring targetExe = GetInstalledExePath();
        return (_wcsicmp(currentExe, targetExe.c_str()) == 0);
    }

    bool Installer::IsInstalled() {
        // Проверяем наличие файла в Program Files
        std::wstring targetExe = GetInstalledExePath();
        if (GetFileAttributesW(targetExe.c_str()) == INVALID_FILE_ATTRIBUTES) {
            return false;
        }

        // Проверяем задачу через COM ITaskService
        HRESULT hr = CoInitializeEx(NULL, COINIT_MULTITHREADED);
        bool taskExists = false;

        ComPtr<ITaskService> pService;
        if (SUCCEEDED(CoCreateInstance(CLSID_TaskScheduler, NULL, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&pService)))) {
            if (SUCCEEDED(pService->Connect(_variant_t(), _variant_t(), _variant_t(), _variant_t()))) {
                ComPtr<ITaskFolder> pRootFolder;
                if (SUCCEEDED(pService->GetFolder(_bstr_t(L"\\"), &pRootFolder))) {
                    ComPtr<IRegisteredTask> pTask;
                    if (SUCCEEDED(pRootFolder->GetTask(_bstr_t(TASK_NAME), &pTask))) {
                        taskExists = true;
                    }
                }
            }
        }

        if (hr == S_OK || hr == S_FALSE) {
            CoUninitialize();
        }

        return taskExists;
    }

    bool Installer::ElevateAndInstall() {
        wchar_t currentExe[MAX_PATH];
        if (GetModuleFileNameW(NULL, currentExe, MAX_PATH) == 0) return false;

        SHELLEXECUTEINFOW sei = {};
        sei.cbSize = sizeof(sei);
        sei.lpVerb = L"runas"; // Однократный запрос UAC
        sei.lpFile = currentExe;
        sei.lpParameters = L"--install";
        sei.nShow = SW_SHOWNORMAL;
        sei.fMask = SEE_MASK_NOCLOSEPROCESS;

        if (ShellExecuteExW(&sei)) {
            if (sei.hProcess) {
                WaitForSingleObject(sei.hProcess, 10000);
                CloseHandle(sei.hProcess);
            }
            return true;
        }
        return false;
    }

    bool Installer::ApplyStrictDataDacl(const std::wstring& path) {
        // Наложение строгого DACL:
        // SYSTEM и BUILTIN\Administrators: Full Control
        // BUILTIN\Users: Read & Execute ONLY (запрет изменения конфигов малварью)
        PSID pSystemSid = NULL;
        PSID pAdminSid = NULL;
        PSID pUsersSid = NULL;

        SID_IDENTIFIER_AUTHORITY ntAuth = SECURITY_NT_AUTHORITY;

        AllocateAndInitializeSid(&ntAuth, 1, SECURITY_LOCAL_SYSTEM_RID, 0, 0, 0, 0, 0, 0, 0, &pSystemSid);
        AllocateAndInitializeSid(&ntAuth, 2, SECURITY_BUILTIN_DOMAIN_RID, DOMAIN_ALIAS_RID_ADMINS, 0, 0, 0, 0, 0, 0, &pAdminSid);
        AllocateAndInitializeSid(&ntAuth, 2, SECURITY_BUILTIN_DOMAIN_RID, DOMAIN_ALIAS_RID_USERS, 0, 0, 0, 0, 0, 0, &pUsersSid);

        EXPLICIT_ACCESS_W ea[3] = {};

        // SYSTEM - Full Control
        ea[0].grfAccessPermissions = GENERIC_ALL;
        ea[0].grfAccessMode = SET_ACCESS;
        ea[0].grfInheritance = OBJECT_INHERIT_ACE | CONTAINER_INHERIT_ACE;
        ea[0].Trustee.TrusteeForm = TRUSTEE_IS_SID;
        ea[0].Trustee.ptstrName = (LPWSTR)pSystemSid;

        // Administrators - Full Control
        ea[1].grfAccessPermissions = GENERIC_ALL;
        ea[1].grfAccessMode = SET_ACCESS;
        ea[1].grfInheritance = OBJECT_INHERIT_ACE | CONTAINER_INHERIT_ACE;
        ea[1].Trustee.TrusteeForm = TRUSTEE_IS_SID;
        ea[1].Trustee.ptstrName = (LPWSTR)pAdminSid;

        // Users - Read & Execute ONLY
        ea[2].grfAccessPermissions = GENERIC_READ | GENERIC_EXECUTE;
        ea[2].grfAccessMode = SET_ACCESS;
        ea[2].grfInheritance = OBJECT_INHERIT_ACE | CONTAINER_INHERIT_ACE;
        ea[2].Trustee.TrusteeForm = TRUSTEE_IS_SID;
        ea[2].Trustee.ptstrName = (LPWSTR)pUsersSid;

        PACL pDacl = NULL;
        DWORD dwRes = SetEntriesInAclW(3, ea, NULL, &pDacl);
        bool success = false;

        if (dwRes == ERROR_SUCCESS) {
            dwRes = SetNamedSecurityInfoW(
                (LPWSTR)path.c_str(),
                SE_FILE_OBJECT,
                DACL_SECURITY_INFORMATION | PROTECTED_DACL_SECURITY_INFORMATION,
                NULL,
                NULL,
                pDacl,
                NULL
            );
            success = (dwRes == ERROR_SUCCESS);
            LocalFree(pDacl);
        }

        if (pSystemSid) FreeSid(pSystemSid);
        if (pAdminSid) FreeSid(pAdminSid);
        if (pUsersSid) FreeSid(pUsersSid);

        return success;
    }

    bool Installer::RegisterTaskScheduler() {
        HRESULT hr = CoInitializeEx(NULL, COINIT_MULTITHREADED);

        ComPtr<ITaskService> pService;
        hr = CoCreateInstance(CLSID_TaskScheduler, NULL, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&pService));
        if (FAILED(hr)) return false;

        hr = pService->Connect(_variant_t(), _variant_t(), _variant_t(), _variant_t());
        if (FAILED(hr)) return false;

        ComPtr<ITaskFolder> pRootFolder;
        hr = pService->GetFolder(_bstr_t(L"\\"), &pRootFolder);
        if (FAILED(hr)) return false;

        // Удаляем существующую если есть
        pRootFolder->DeleteTask(_bstr_t(TASK_NAME), 0);

        ComPtr<ITaskDefinition> pTask;
        hr = pService->NewTask(0, &pTask);
        if (FAILED(hr)) return false;

        // Настройка автора
        ComPtr<IRegistrationInfo> pRegInfo;
        if (SUCCEEDED(pTask->get_RegistrationInfo(&pRegInfo))) {
            pRegInfo->put_Author(_bstr_t(L"KristMr"));
            pRegInfo->put_Description(_bstr_t(L"KristMr High-Performance Security & Engine Optimizer"));
        }

        // Настройка Principal
        ComPtr<IPrincipal> pPrincipal;
        if (SUCCEEDED(pTask->get_Principal(&pPrincipal))) {
            pPrincipal->put_Id(_bstr_t(L"KristMrPrincipal"));
            pPrincipal->put_LogonType(TASK_LOGON_INTERACTIVE_TOKEN);
            pPrincipal->put_RunLevel(TASK_RUNLEVEL_HIGHEST);
        }

        // Настройка Settings
        ComPtr<ITaskSettings> pSettings;
        if (SUCCEEDED(pTask->get_Settings(&pSettings))) {
            pSettings->put_StartWhenAvailable(VARIANT_TRUE);
            pSettings->put_DisallowStartIfOnBatteries(VARIANT_FALSE);
            pSettings->put_StopIfGoingOnBatteries(VARIANT_FALSE);
            pSettings->put_ExecutionTimeLimit(_bstr_t(L"PT0S")); // Запрет принудительного убийства через 72 ч
            pSettings->put_Priority(4); // Высокий нормальный приоритет
        }

        // Настройка триггера TASK_TRIGGER_LOGON
        ComPtr<ITriggerCollection> pTriggers;
        if (SUCCEEDED(pTask->get_Triggers(&pTriggers))) {
            ComPtr<ITrigger> pTrigger;
            if (SUCCEEDED(pTriggers->Create(TASK_TRIGGER_LOGON, &pTrigger))) {
                pTrigger->put_Enabled(VARIANT_TRUE);
            }
        }

        // Настройка действия EXEC
        ComPtr<IActionCollection> pActions;
        if (SUCCEEDED(pTask->get_Actions(&pActions))) {
            ComPtr<IAction> pAction;
            if (SUCCEEDED(pActions->Create(TASK_ACTION_EXEC, &pAction))) {
                ComPtr<IExecAction> pExecAction;
                if (SUCCEEDED(pAction.As(&pExecAction))) {
                    std::wstring targetExe = GetInstalledExePath();
                    pExecAction->put_Path(_bstr_t(targetExe.c_str()));
                    pExecAction->put_WorkingDirectory(_bstr_t(GetProgramFilesAppDir().c_str()));
                }
            }
        }

        // Регистрация задачи
        ComPtr<IRegisteredTask> pRegisteredTask;
        hr = pRootFolder->RegisterTaskDefinition(
            _bstr_t(TASK_NAME),
            pTask.Get(),
            TASK_CREATE_OR_UPDATE,
            _variant_t(),
            _variant_t(),
            TASK_LOGON_INTERACTIVE_TOKEN,
            _variant_t(L""),
            &pRegisteredTask
        );

        return SUCCEEDED(hr);
    }

    bool Installer::CreateStartMenuShortcut() {
        wchar_t startMenuPath[MAX_PATH];
        if (FAILED(SHGetFolderPathW(NULL, CSIDL_COMMON_PROGRAMS, NULL, 0, startMenuPath))) {
            if (FAILED(SHGetFolderPathW(NULL, CSIDL_PROGRAMS, NULL, 0, startMenuPath))) {
                return false;
            }
        }

        std::wstring shortcutPath = std::wstring(startMenuPath) + L"\\KristMr.lnk";
        std::wstring targetExe = GetInstalledExePath();

        ComPtr<IShellLinkW> psl;
        if (FAILED(CoCreateInstance(CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&psl)))) {
            return false;
        }

        psl->SetPath(targetExe.c_str());
        psl->SetWorkingDirectory(GetProgramFilesAppDir().c_str());
        psl->SetDescription(L"KristMr Security & Optimization Monitor");

        // Установка AppUserModelId
        ComPtr<IPropertyStore> pps;
        if (SUCCEEDED(psl.As(&pps))) {
            PROPVARIANT pv;
            InitPropVariantFromString(APP_USER_MODEL_ID, &pv);
            pps->SetValue(PKEY_AppUserModel_ID, pv);
            pps->Commit();
            PropVariantClear(&pv);
        }

        ComPtr<IPersistFile> ppf;
        if (SUCCEEDED(psl.As(&ppf))) {
            return SUCCEEDED(ppf->Save(shortcutPath.c_str(), TRUE));
        }

        return false;
    }

    bool Installer::PerformInstallation() {
        wchar_t currentExe[MAX_PATH];
        if (GetModuleFileNameW(NULL, currentExe, MAX_PATH) == 0) return false;

        std::wstring targetDir = GetProgramFilesAppDir();
        std::wstring targetExe = GetInstalledExePath();
        std::wstring dataDir = GetProgramDataAppDir();
        std::wstring configDir = dataDir + L"\\config";
        std::wstring quarantineDir = dataDir + L"\\Quarantine";

        // Создаем каталоги
        CreateDirectoryW(targetDir.c_str(), NULL);
        CreateDirectoryW(dataDir.c_str(), NULL);
        CreateDirectoryW(configDir.c_str(), NULL);
        CreateDirectoryW(quarantineDir.c_str(), NULL);

        // Копируем исполняемый файл
        if (_wcsicmp(currentExe, targetExe.c_str()) != 0) {
            CopyFileW(currentExe, targetExe.c_str(), FALSE);
        }

        // Накладываем строгие DACL
        ApplyStrictDataDacl(dataDir);
        ApplyStrictDataDacl(configDir);

        // Регистрируем в Task Scheduler
        RegisterTaskScheduler();

        // Создаем ярлык в Start Menu
        CreateStartMenuShortcut();

        // Запуск рабочего процесса если запускались из внешнего пути
        if (_wcsicmp(currentExe, targetExe.c_str()) != 0) {
            STARTUPINFOW si = { sizeof(si) };
            PROCESS_INFORMATION pi = {};
            if (CreateProcessW(targetExe.c_str(), NULL, NULL, NULL, FALSE, 0, NULL, targetDir.c_str(), &si, &pi)) {
                CloseHandle(pi.hThread);
                CloseHandle(pi.hProcess);
            }
        }

        return true;
    }

}
