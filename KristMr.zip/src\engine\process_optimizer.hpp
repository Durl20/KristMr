#pragma once
#include "../common.hpp"

namespace KristMr {

    class ProcessOptimizer {
    public:
        static void Initialize(const std::vector<std::wstring>& blacklist);

        // Периодическое применение троттлинга для процессов блэклиста
        static void OptimizeBlacklistProcesses();

        // Обновление Game Focus для активного окна
        static void UpdateGameFocus();

        // Восстановление оригинальных приоритетов при выходе
        static void RestoreProcessPriorities();

    private:
        static void ApplyThrottlingToProcess(DWORD pid);
        static void SetProcessIoPriorityVeryLow(HANDLE hProcess);

        inline static std::vector<std::wstring> s_blacklist;
        inline static DWORD s_lastBoostedPid = 0;
        inline static std::mutex s_mutex;
    };

}
