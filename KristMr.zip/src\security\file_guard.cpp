#include "file_guard.hpp"
#include "../obfuscation.hpp"

namespace KristMr {

    HANDLE FileGuard::OpenSafeFile(const std::wstring& path, DWORD desiredAccess, DWORD shareMode, DWORD creationDisposition) {
        // Открытие ТОЛЬКО с флагом FILE_FLAG_OPEN_REPARSE_POINT для исключения следования по symlink/junction
        return CreateFileW(
            path.c_str(),
            desiredAccess,
            shareMode,
            NULL,
            creationDisposition,
            FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OPEN_REPARSE_POINT,
            NULL
        );
    }

    FileValidationResult FileGuard::ValidateFileHandle(HANDLE hFile, const std::wstring& expectedPath) {
        FileValidationResult res;
        if (hFile == INVALID_HANDLE_VALUE || hFile == NULL) {
            res.errorReason = L"Invalid file handle";
            return res;
        }

        // 1. Проверка жестких ссылок через FileStandardInfo
        FILE_STANDARD_INFO stdInfo = {};
        if (GetFileInformationByHandleEx(hFile, FileStandardInfo, &stdInfo, sizeof(stdInfo))) {
            res.numberOfLinks = stdInfo.NumberOfLinks;
            if (stdInfo.NumberOfLinks > 1) {
                res.errorReason = L"Hardlink attack detected (NumberOfLinks > 1)";
                return res; // Немедленно исключаем
            }
        } else {
            res.errorReason = L"Failed to query FileStandardInfo";
            return res;
        }

        // 2. Проверка атрибутов на Reparse Point
        FILE_ATTRIBUTE_TAG_INFO tagInfo = {};
        if (GetFileInformationByHandleEx(hFile, FileAttributeTagInfo, &tagInfo, sizeof(tagInfo))) {
            if (tagInfo.FileAttributes & FILE_ATTRIBUTE_REPARSE_POINT) {
                res.isReparsePoint = true;
                res.errorReason = L"Reparse point / Junction / Symlink detected";
                return res;
            }
        }

        // 3. Сверка канонического пути через GetFinalPathNameByHandleW
        wchar_t finalPathBuf[MAX_PATH * 2] = {};
        DWORD pathLen = GetFinalPathNameByHandleW(hFile, finalPathBuf, _countof(finalPathBuf), FILE_NAME_NORMALIZED | VOLUME_NAME_DOS);
        if (pathLen > 0 && pathLen < _countof(finalPathBuf)) {
            std::wstring finalPathStr = finalPathBuf;
            // Убираем префикс \\?\ если присутствует
            if (finalPathStr.rfind(L"\\\\?\\", 0) == 0) {
                finalPathStr = finalPathStr.substr(4);
            }
            res.finalPath = finalPathStr;

            std::wstring normExpected = expectedPath;
            if (normExpected.rfind(L"\\\\?\\", 0) == 0) {
                normExpected = normExpected.substr(4);
            }

            // Нечувствительное сравнение путей
            if (_wcsicmp(finalPathStr.c_str(), normExpected.c_str()) != 0) {
                // Если пути не совпадают, это подмена через Junction или symlink каталога
                res.errorReason = L"Path mismatch (Junction redirect detected)";
                return res;
            }
        }

        res.isValid = true;
        return res;
    }

    bool FileGuard::IsReparsePointPath(const std::wstring& path) {
        DWORD attrs = GetFileAttributesW(path.c_str());
        if (attrs == INVALID_FILE_ATTRIBUTES) return false;
        return (attrs & FILE_ATTRIBUTE_REPARSE_POINT) != 0;
    }

    void FileGuard::CleanTempJunkSafe() {
        wchar_t tempPath[MAX_PATH];
        DWORD len = GetTempPathW(MAX_PATH, tempPath);
        if (len == 0 || len > MAX_PATH) return;

        try {
            for (const auto& entry : fs::directory_iterator(tempPath, fs::directory_options::skip_permission_denied)) {
                std::error_code ec;
                if (!entry.is_regular_file(ec)) continue;

                std::wstring filePath = entry.path().wstring();

                // Исключаем себя
                if (SelfProtection::IsSelfFile(filePath)) continue;

                // Безопасное открытие
                HANDLE hFile = OpenSafeFile(filePath, GENERIC_READ | DELETE, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, OPEN_EXISTING);
                if (hFile == INVALID_HANDLE_VALUE) continue;

                // Проверка условий безопасности:
                // Файлы удаляются только при проверке отсутствия флага FILE_ATTRIBUTE_REPARSE_POINT и значении nNumberOfLinks == 1
                FileValidationResult val = ValidateFileHandle(hFile, filePath);
                if (val.isValid && !val.isReparsePoint && val.numberOfLinks == 1) {
                    FILE_DISPOSITION_INFO dispInfo = { TRUE };
                    SetFileInformationByHandle(hFile, FileDispositionInfo, &dispInfo, sizeof(dispInfo));
                }
                CloseHandle(hFile);
            }
        } catch (...) {
            // Игнорируем любые сбои доступа
        }
    }

}
