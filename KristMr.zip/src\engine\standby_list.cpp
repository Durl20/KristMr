#include "standby_list.hpp"

#ifndef SE_PROFILE_SINGLE_PROCESS_NAME
#define SE_PROFILE_SINGLE_PROCESS_NAME L"SeProfileSingleProcessPrivilege"
#endif

namespace KristMr {

    bool StandbyListManager::EnableRequiredPrivileges() {
        HANDLE hToken = NULL;
        if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken)) {
            return false;
        }

        auto enablePriv = [hToken](const wchar_t* privName) -> bool {
            LUID luid;
            if (!LookupPrivilegeValueW(NULL, privName, &luid)) return false;

            TOKEN_PRIVILEGES tp = {};
            tp.PrivilegeCount = 1;
            tp.Privileges[0].Luid = luid;
            tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

            SetLastError(ERROR_SUCCESS);
            AdjustTokenPrivileges(hToken, FALSE, &tp, sizeof(tp), NULL, NULL);
            return (GetLastError() == ERROR_SUCCESS);
        };

        bool okProfile = enablePriv(SE_PROFILE_SINGLE_PROCESS_NAME);
        bool okQuota = enablePriv(SE_INCREASE_QUOTA_NAME);

        CloseHandle(hToken);
        return (okProfile && okQuota);
    }

    bool StandbyListManager::PurgeStandbyListOnce() {
        if (s_alreadyPurged.exchange(true)) {
            return true; // Уже выполнялось
        }

        if (!EnableRequiredPrivileges()) {
            return false;
        }

        HMODULE hNtDll = GetModuleHandleW(L"ntdll.dll");
        if (!hNtDll) {
            hNtDll = LoadLibraryW(L"ntdll.dll");
        }
        if (!hNtDll) return false;

        pfnNtSetSystemInformation pfnNtSetSysInfo = reinterpret_cast<pfnNtSetSystemInformation>(
            GetProcAddress(hNtDll, "NtSetSystemInformation")
        );
        if (!pfnNtSetSysInfo) return false;

        // Cmd = 4: MemoryPurgeStandbyList
        SYSTEM_MEMORY_LIST_COMMAND cmd = MemoryPurgeStandbyList;
        NTSTATUS status = pfnNtSetSysInfo(SystemMemoryListInformation, &cmd, sizeof(cmd));

        return (status == STATUS_SUCCESS);
    }

}
