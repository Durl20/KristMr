cbuffer ConstantBuffer : register(b0)
{
    float4 CurrentColor;
    float Time;
    float GlobalAlpha;
    float Feather;
    float Padding;
};

struct VS_INPUT
{
    float3 Position : POSITION;
    float2 UV : TEXCOORD0;
    float4 Color : COLOR;
    float Size : PSIZE;
};

struct PS_INPUT
{
    float4 Position : SV_POSITION;
    float2 UV : TEXCOORD0;
    float4 Color : COLOR;
};

PS_INPUT VSMain(VS_INPUT input)
{
    PS_INPUT output;
    output.Position = float4(input.Position, 1.0f);
    output.UV = input.UV;
    output.Color = input.Color;
    return output;
}

float4 PSMain(PS_INPUT input) : SV_TARGET
{
    // Радиальное расстояние от центра частицы (0.0 в центре, 1.0 на краю)
    float dist = length(input.UV - float2(0.5f, 0.5f)) * 2.0f;
    if (dist > 1.0f) {
        discard;
    }
    
    // Корректный smoothstep (edge0 < edge1) для идеального сглаживания
    float alpha = (1.0f - smoothstep(0.65f, 1.0f, dist)) * GlobalAlpha * input.Color.a;
    
    // Ослепительно белое горячее квантовое ядро в центре частицы (как на фото)
    float core = saturate(1.0f - dist * 2.2f);
    float3 baseColor = CurrentColor.rgb * input.Color.rgb;
    float3 finalRgb = lerp(baseColor, float3(0.96f, 0.99f, 1.0f), core * 0.88f);
    
    return float4(finalRgb, alpha);
}
