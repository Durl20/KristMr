#pragma once
#include "../common.hpp"

namespace KristMr {

    enum class ScanVerdict {
        Clean,          // Чистый
        BypassAllowed,  // Безопасный unlocker/bypass/patcher (белый список)
        Suspicious,     // Неизвестная репутация / подозрительный
        MalwareHardVeto // Hard Veto: майнер, эксфильтрация, инъекция -> немедленный карантин
    };

    struct PeScanResult {
        ScanVerdict verdict = ScanVerdict::Clean;
        std::string sha256 = "";
        std::string detectedReason = "";
        bool isPeFile = false;
    };

    class PeParser {
    public:
        // Полный эвристический анализ файла
        static PeScanResult AnalyzeFile(const std::wstring& filePath, const std::vector<std::wstring>& whitelist);

        // Вычисление SHA-256 хэша
        static std::string ComputeSha256(const std::vector<uint8_t>& fileData);

    private:
        // Проверка PE заголовков
        static bool ValidatePeStructure(const uint8_t* data, size_t size);

        // Проверка правила Hard Veto (зашифрованные маркеры)
        static bool CheckHardVetoMarkers(const uint8_t* data, size_t size, std::string& outMarker);

        // Проверка белого списка по именам (unlocker, bypass, activator...)
        static bool IsNameWhitelisted(const std::wstring& filePath, const std::vector<std::wstring>& whitelist);
    };

}
