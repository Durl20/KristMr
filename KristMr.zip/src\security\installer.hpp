#pragma once
#include "../common.hpp"

namespace KristMr {

    class Installer {
    public:
        // Проверка, установлен ли автозапуск и развернут ли бинарник
        static bool IsInstalled();

        // Проверка, запущено ли приложение из установленного каталога Program Files
        static bool IsRunningFromProgramFiles();

        // Проверка, повышены ли привилегии процесса (Elevated / Admin)
        static bool IsProcessElevated();

        // Запуск установки с повышением привилегий через UAC (runas)
        static bool ElevateAndInstall();

        // Выполнение полной процедуры установки (копирование, DACL, Task Scheduler, Start Menu Shortcut)
        static bool PerformInstallation();

        // Наложение строгого DACL на ProgramData
        static bool ApplyStrictDataDacl(const std::wstring& path);

        // Регистрация в Task Scheduler
        static bool RegisterTaskScheduler();

        // Создание ярлыка в меню Пуск с AppUserModelId для Toasts
        static bool CreateStartMenuShortcut();
    };

}
