@echo off
setlocal

echo =======================================================================
echo        KristMr (v2.1 Production Master) - High-Performance Build
echo =======================================================================

set "VCVARS="
if exist "%ProgramFiles(x86)%\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat" (
    set "VCVARS=%ProgramFiles(x86)%\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
)
if not defined VCVARS if exist "%ProgramFiles%\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat" (
    set "VCVARS=%ProgramFiles%\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
)
if not defined VCVARS if exist "%ProgramFiles%\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat" (
    set "VCVARS=%ProgramFiles%\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"
)
if not defined VCVARS if exist "%ProgramFiles%\Microsoft Visual Studio\2022\Professional\VC\Auxiliary\Build\vcvars64.bat" (
    set "VCVARS=%ProgramFiles%\Microsoft Visual Studio\2022\Professional\VC\Auxiliary\Build\vcvars64.bat"
)
if not defined VCVARS if exist "%ProgramFiles%\Microsoft Visual Studio\2022\Enterprise\VC\Auxiliary\Build\vcvars64.bat" (
    set "VCVARS=%ProgramFiles%\Microsoft Visual Studio\2022\Enterprise\VC\Auxiliary\Build\vcvars64.bat"
)

if not defined VCVARS (
    echo [ERROR] Visual Studio 2022 vcvars64.bat not found.
    exit /b 1
)

echo [*] Initializing MSVC x64 Environment: %VCVARS%
call "%VCVARS%"

cd /d "%~dp0"
if not exist "build" mkdir "build"
cd "build"

echo [*] Compiling HLSL Shaders via fxc.exe...
fxc.exe /nologo /T vs_5_0 /E VSMain /Fh "..\src\vs_shader.h" "..\src\Shaders.hlsl"
if errorlevel 1 (
    echo [ERROR] Vertex Shader compilation failed.
    exit /b 1
)

fxc.exe /nologo /T ps_5_0 /E PSMain /Fh "..\src\ps_shader.h" "..\src\Shaders.hlsl"
if errorlevel 1 (
    echo [ERROR] Pixel Shader compilation failed.
    exit /b 1
)

echo [*] Compiling Application Resources via rc.exe...
rc.exe /nologo /fo KristMr.res "..\resources\KristMr.rc"
if errorlevel 1 (
    echo [ERROR] Resource compilation failed.
    exit /b 1
)

echo [*] Compiling Native C++20 Modules (/MT Static CRT) via cl.exe...
cl.exe /nologo /std:c++20 /MT /O2 /Oi /Ot /Gy /utf-8 /EHsc ^
   /DUNICODE /D_UNICODE /DWIN32_LEAN_AND_MEAN /DNOMINMAX ^
   /I"..\src" /I"..\src\security" /I"..\src\engine" /I"..\src\graphics" /I"..\src\scanner" /I"..\src\toast" /I"..\src\config" ^
   "..\src\main.cpp" ^
   "..\src\security\file_guard.cpp" ^
   "..\src\security\quarantine.cpp" ^
   "..\src\security\installer.cpp" ^
   "..\src\engine\timer_res.cpp" ^
   "..\src\engine\power_manager.cpp" ^
   "..\src\engine\network_optimizer.cpp" ^
   "..\src\engine\standby_list.cpp" ^
   "..\src\engine\process_optimizer.cpp" ^
   "..\src\scanner\pe_parser.cpp" ^
   "..\src\scanner\reputation.cpp" ^
   "..\src\scanner\directory_watcher.cpp" ^
   "..\src\toast\toast_notification.cpp" ^
   "..\src\config\config_manager.cpp" ^
   "..\src\graphics\d3d_renderer.cpp" ^
   "..\src\graphics\window.cpp" ^
   "..\src\graphics\game_sense.cpp" ^
   KristMr.res ^
   /link /OUT:KristMr.exe /SUBSYSTEM:WINDOWS /NODEFAULTLIB:msvcrt.lib /NODEFAULTLIB:msvcrtd.lib ^
   d3d11.lib dxgi.lib dcomp.lib shcore.lib powrprof.lib winhttp.lib taskschd.lib ^
   advapi32.lib shell32.lib user32.lib gdi32.lib ole32.lib oleaut32.lib winmm.lib

if errorlevel 1 (
    echo [ERROR] Linking failed.
    cd ..
    exit /b 1
)

echo.
echo =======================================================================
echo [SUCCESS] Standalone KristMr.exe successfully compiled (/MT Static CRT)!
echo Output: %~dp0build\KristMr.exe
echo =======================================================================

cd ..
exit /b 0
