#include "power_manager.hpp"

namespace KristMr {

    static const GUID GUID_PROCESSOR_SETTINGS_SUBGROUP_LOCAL = {
        0x54533251, 0x82be, 0x4824, {0x96, 0xc1, 0x47, 0xb6, 0x0b, 0x74, 0x0d, 0x00}
    };

    static const GUID GUID_CPM_MIN_CORES_LOCAL = {
        0x0cc5b647, 0xc1df, 0x4637, {0x89, 0x1a, 0xde, 0xc3, 0x5c, 0x31, 0x85, 0x83}
    };

    std::wstring PowerManager::GetPowerBackupFilePath() {
        return GetProgramDataAppDir() + L"\\last_power_scheme.bin";
    }

    bool PowerManager::SaveGuidToFile(const GUID& guid, const std::wstring& path) {
        HANDLE hFile = CreateFileW(
            path.c_str(),
            GENERIC_WRITE,
            0,
            NULL,
            CREATE_ALWAYS,
            FILE_ATTRIBUTE_NORMAL | FILE_FLAG_WRITE_THROUGH, // Гарантированный сброс на диск
            NULL
        );

        if (hFile == INVALID_HANDLE_VALUE) return false;

        DWORD bytesWritten = 0;
        BOOL res = WriteFile(hFile, &guid, sizeof(GUID), &bytesWritten, NULL);
        CloseHandle(hFile);
        return (res && bytesWritten == sizeof(GUID));
    }

    bool PowerManager::LoadGuidFromFile(GUID& guid, const std::wstring& path) {
        HANDLE hFile = CreateFileW(
            path.c_str(),
            GENERIC_READ,
            FILE_SHARE_READ,
            NULL,
            OPEN_EXISTING,
            FILE_ATTRIBUTE_NORMAL,
            NULL
        );

        if (hFile == INVALID_HANDLE_VALUE) return false;

        DWORD bytesRead = 0;
        BOOL res = ReadFile(hFile, &guid, sizeof(GUID), &bytesRead, NULL);
        CloseHandle(hFile);
        return (res && bytesRead == sizeof(GUID));
    }

    CpuTopologyType PowerManager::DetectCpuTopology() {
        DWORD bufferSize = 0;
        GetLogicalProcessorInformationEx(RelationProcessorCore, NULL, &bufferSize);
        if (bufferSize == 0) return CpuTopologyType::Monolithic;

        std::vector<uint8_t> buffer(bufferSize);
        PSYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX pInfo = reinterpret_cast<PSYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX>(buffer.data());

        if (GetLogicalProcessorInformationEx(RelationProcessorCore, pInfo, &bufferSize)) {
            uint8_t* current = buffer.data();
            uint8_t* end = buffer.data() + bufferSize;
            int firstEfficiency = -1;
            bool hasDifferentEfficiency = false;

            while (current < end) {
                PSYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX item = reinterpret_cast<PSYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX>(current);
                if (item->Relationship == RelationProcessorCore) {
                    BYTE eff = item->Processor.EfficiencyClass;
                    if (firstEfficiency == -1) {
                        firstEfficiency = eff;
                    } else if (eff != firstEfficiency) {
                        hasDifferentEfficiency = true;
                        break;
                    }
                }
                current += item->Size;
            }

            if (hasDifferentEfficiency) {
                return CpuTopologyType::IntelHybrid; // P+E cores (Intel Raptor Lake / Alder Lake и новее)
            }
        }

        // Проверка асимметричного L3 кэша (AMD 3D V-Cache 7900X3D / 7950X3D)
        DWORD cacheBufferSize = 0;
        GetLogicalProcessorInformationEx(RelationCache, NULL, &cacheBufferSize);
        if (cacheBufferSize > 0) {
            std::vector<uint8_t> cacheBuf(cacheBufferSize);
            PSYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX pCacheInfo = reinterpret_cast<PSYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX>(cacheBuf.data());

            if (GetLogicalProcessorInformationEx(RelationCache, pCacheInfo, &cacheBufferSize)) {
                uint8_t* current = cacheBuf.data();
                uint8_t* end = cacheBuf.data() + cacheBufferSize;
                std::vector<DWORD> l3Sizes;

                while (current < end) {
                    PSYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX item = reinterpret_cast<PSYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX>(current);
                    if (item->Relationship == RelationCache && item->Cache.Level == 3) {
                        l3Sizes.push_back(item->Cache.CacheSize);
                    }
                    current += item->Size;
                }

                if (l3Sizes.size() > 1) {
                    DWORD firstL3 = l3Sizes[0];
                    for (size_t i = 1; i < l3Sizes.size(); ++i) {
                        if (l3Sizes[i] != firstL3) {
                            return CpuTopologyType::AmdAsymmetricL3; // Асимметричный кэш L3
                        }
                    }
                }
            }
        }

        return CpuTopologyType::Monolithic;
    }

    void PowerManager::CheckAndRecoverCrashedScheme() {
        std::wstring backupPath = GetPowerBackupFilePath();
        GUID crashedGuid = {};
        if (LoadGuidFromFile(crashedGuid, backupPath)) {
            // Восстанавливаем оригинальную схему после предыдущего аварийного сбоя
            PowerSetActiveScheme(NULL, &crashedGuid);
            DeleteFileW(backupPath.c_str());
        }
    }

    bool PowerManager::EnableHyperPowerProfile() {
        // 1. Получаем текущую активную схему
        GUID* pOrigGuid = NULL;
        if (PowerGetActiveScheme(NULL, &pOrigGuid) != ERROR_SUCCESS || !pOrigGuid) {
            return false;
        }

        s_originalSchemeGuid = *pOrigGuid;
        s_hasOriginalScheme = true;

        // Сохраняем на диск перед внесением изменений
        SaveGuidToFile(s_originalSchemeGuid, GetPowerBackupFilePath());

        // Немедленное освобождение pOrigGuid
        LocalFree(pOrigGuid);

        // 2. Создаем или настраиваем схему High Performance / Hyper
        // Клонируем схему высокой производительности (GUID_MIN_POWER_SAVINGS)
        GUID* pNewScheme = NULL;
        if (PowerDuplicateScheme(NULL, &GUID_MIN_POWER_SAVINGS, &pNewScheme) == ERROR_SUCCESS && pNewScheme) {
            s_hyperSchemeGuid = *pNewScheme;

            const wchar_t* schemeName = L"KristMr Hyper Profile";
            PowerWriteFriendlyName(NULL, &s_hyperSchemeGuid, NULL, NULL, (UCHAR*)schemeName, (DWORD)(wcslen(schemeName) * sizeof(wchar_t) + 2));

            // Проверяем топологию CPU
            CpuTopologyType topo = DetectCpuTopology();
            if (topo == CpuTopologyType::Monolithic) {
                // На монолитных CPU отключаем парковку ядер (100%)
                DWORD minCores = 100;
                PowerWriteACValueIndex(NULL, &s_hyperSchemeGuid, &GUID_PROCESSOR_SETTINGS_SUBGROUP_LOCAL, &GUID_CPM_MIN_CORES_LOCAL, minCores);
                PowerWriteDCValueIndex(NULL, &s_hyperSchemeGuid, &GUID_PROCESSOR_SETTINGS_SUBGROUP_LOCAL, &GUID_CPM_MIN_CORES_LOCAL, minCores);
            }
            // Если Intel Hybrid или AMD Asymmetric L3, твик парковки НЕ применяется

            PowerSetActiveScheme(NULL, &s_hyperSchemeGuid);
            LocalFree(pNewScheme);
            return true;
        } else {
            // Если клонирование не удалось, активируем стандартную схему высокой производительности
            GUID highPerf = GUID_MIN_POWER_SAVINGS;
            PowerSetActiveScheme(NULL, &highPerf);
            return true;
        }
    }

    void PowerManager::RestoreOriginalPowerScheme() {
        if (s_hasOriginalScheme) {
            PowerSetActiveScheme(NULL, &s_originalSchemeGuid);

            // Удаляем временный профиль если создавался
            if (memcmp(&s_hyperSchemeGuid, &GUID_NULL, sizeof(GUID)) != 0) {
                PowerDeleteScheme(NULL, &s_hyperSchemeGuid);
            }

            s_hasOriginalScheme = false;
        }

        // Удаляем backup-файл
        DeleteFileW(GetPowerBackupFilePath().c_str());
    }

}
