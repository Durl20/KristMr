#pragma once
#include "../common.hpp"

namespace KristMr {

    struct RegistryBackupData {
        bool hasNetworkThrottling = false;
        DWORD origNetworkThrottling = 0;
        bool hasSystemResponsiveness = false;
        DWORD origSystemResponsiveness = 0;
    };

    class NetworkOptimizer {
    public:
        // Сброс DNS кэша Windows
        static bool FlushDnsCache();

        // Оптимизация задержек мультимедиа и сети (NetworkThrottlingIndex / SystemResponsiveness)
        static bool ApplyNetworkTweaks();

        // Восстановление оригинальных значений реестра из бэкапа
        static void RestoreRegistryTweaks();

    private:
        static std::wstring GetRegistryBackupFilePath();
        static bool SaveBackup(const RegistryBackupData& data);
        static bool LoadBackup(RegistryBackupData& data);
    };

}
