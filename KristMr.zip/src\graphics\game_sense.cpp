#include "game_sense.hpp"

namespace KristMr {

    bool GameSense::CheckFullScreenGame() {
        // 1. Проверка через SHQueryUserNotificationState
        QUERY_USER_NOTIFICATION_STATE state;
        if (SUCCEEDED(SHQueryUserNotificationState(&state))) {
            if (state == QUNS_RUNNING_D3D_FULL_SCREEN) {
                return true;
            }
        }

        // 2. Сравнение геометрии активного окна с границами монитора
        HWND hFg = GetForegroundWindow();
        if (hFg && hFg != GetDesktopWindow() && hFg != GetShellWindow()) {
            wchar_t className[256];
            GetClassNameW(hFg, className, 256);
            if (_wcsicmp(className, L"Progman") != 0 && _wcsicmp(className, L"WorkerW") != 0) {
                RECT wndRect;
                if (GetWindowRect(hFg, &wndRect)) {
                    HMONITOR hMon = MonitorFromWindow(hFg, MONITOR_DEFAULTTONEAREST);
                    MONITORINFO mi = { sizeof(mi) };
                    if (GetMonitorInfoW(hMon, &mi)) {
                        // Если активное окно полностью закрывает монитор
                        if (wndRect.left <= mi.rcMonitor.left &&
                            wndRect.top <= mi.rcMonitor.top &&
                            wndRect.right >= mi.rcMonitor.right &&
                            wndRect.bottom >= mi.rcMonitor.bottom) {
                            
                            LONG style = GetWindowLongW(hFg, GWL_STYLE);
                            // Если окно не имеет заголовка (типично для Borderless/Fullscreen игр)
                            if ((style & WS_CAPTION) != WS_CAPTION) {
                                return true;
                            }
                        }
                    }
                }
            }
        }

        return false;
    }

    void GameSense::MonitorThread() {
        while (s_running) {
            bool game = CheckFullScreenGame();
            s_isGameRunning.store(game);

            // Опрос каждые 2.5 секунды
            for (int i = 0; i < 25 && s_running; ++i) {
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
            }
        }
    }

    void GameSense::Start() {
        if (s_running) return;
        s_running = true;
        s_thread = std::thread(MonitorThread);
    }

    void GameSense::Stop() {
        if (!s_running) return;
        s_running = false;
        if (s_thread.joinable()) {
            s_thread.join();
        }
    }

}
