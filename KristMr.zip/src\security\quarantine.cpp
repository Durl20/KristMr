#include "quarantine.hpp"
#include "file_guard.hpp"
#include "../obfuscation.hpp"

#ifndef FILE_RENAME_FLAG_REPLACE_IF_EXISTS
#define FILE_RENAME_FLAG_REPLACE_IF_EXISTS 0x00000001
#endif
#ifndef FILE_RENAME_FLAG_POSIX_SEMANTICS
#define FILE_RENAME_FLAG_POSIX_SEMANTICS 0x00000002
#endif

#ifndef FileRenameInfoEx
#define FileRenameInfoEx ((FILE_INFO_BY_HANDLE_CLASS)22)
#endif
#ifndef FileDispositionInfoEx
#define FileDispositionInfoEx ((FILE_INFO_BY_HANDLE_CLASS)21)
#endif

#ifndef FILE_DISPOSITION_FLAG_DELETE
#define FILE_DISPOSITION_FLAG_DELETE 0x00000001
#endif
#ifndef FILE_DISPOSITION_FLAG_POSIX_SEMANTICS
#define FILE_DISPOSITION_FLAG_POSIX_SEMANTICS 0x00000002
#endif

typedef struct _FILE_DISPOSITION_INFO_EX_LOCAL {
    DWORD Flags;
} FILE_DISPOSITION_INFO_EX_LOCAL;

namespace KristMr {

    std::wstring QuarantineManager::GetMainQuarantineDir() {
        return GetProgramDataAppDir() + L"\\Quarantine";
    }

    std::wstring QuarantineManager::GetVolumeRoot(const std::wstring& path) {
        wchar_t volumePath[MAX_PATH] = {};
        if (GetVolumePathNameW(path.c_str(), volumePath, MAX_PATH)) {
            return volumePath;
        }
        if (path.length() >= 3 && path[1] == L':' && path[2] == L'\\') {
            return path.substr(0, 3);
        }
        return L"C:\\";
    }

    void QuarantineManager::Initialize() {
        std::wstring mainDir = GetMainQuarantineDir();
        CreateDirectoryW(GetProgramDataAppDir().c_str(), NULL);
        CreateDirectoryW(mainDir.c_str(), NULL);
        ApplyNtfsPrivilegeTrap(mainDir);
    }

    bool QuarantineManager::ApplyNtfsPrivilegeTrap(const std::wstring& path) {
        // 1. Получение SID NT AUTHORITY\SYSTEM (S-1-5-18)
        PSID pSystemSid = NULL;
        SID_IDENTIFIER_AUTHORITY ntAuth = SECURITY_NT_AUTHORITY;
        if (!AllocateAndInitializeSid(&ntAuth, 1, SECURITY_LOCAL_SYSTEM_RID, 0, 0, 0, 0, 0, 0, 0, &pSystemSid)) {
            return false;
        }

        // 2. Получение SID группы Everyone (S-1-1-0)
        PSID pEveryoneSid = NULL;
        SID_IDENTIFIER_AUTHORITY worldAuth = SECURITY_WORLD_SID_AUTHORITY;
        if (!AllocateAndInitializeSid(&worldAuth, 1, SECURITY_WORLD_RID, 0, 0, 0, 0, 0, 0, 0, &pEveryoneSid)) {
            FreeSid(pSystemSid);
            return false;
        }

        // 3. Формирование DACL:
        //    - NT AUTHORITY\SYSTEM: GENERIC_ALL
        //    - Everyone: DENY FILE_EXECUTE
        EXPLICIT_ACCESS_W ea[2] = {};

        // SYSTEM Full Control
        ea[0].grfAccessPermissions = GENERIC_ALL;
        ea[0].grfAccessMode = SET_ACCESS;
        ea[0].grfInheritance = OBJECT_INHERIT_ACE | CONTAINER_INHERIT_ACE;
        ea[0].Trustee.TrusteeForm = TRUSTEE_IS_SID;
        ea[0].Trustee.TrusteeType = TRUSTEE_IS_USER;
        ea[0].Trustee.ptstrName = (LPWSTR)pSystemSid;

        // DENY FILE_EXECUTE для Everyone
        ea[1].grfAccessPermissions = FILE_EXECUTE;
        ea[1].grfAccessMode = DENY_ACCESS;
        ea[1].grfInheritance = OBJECT_INHERIT_ACE | CONTAINER_INHERIT_ACE;
        ea[1].Trustee.TrusteeForm = TRUSTEE_IS_SID;
        ea[1].Trustee.TrusteeType = TRUSTEE_IS_WELL_KNOWN_GROUP;
        ea[1].Trustee.ptstrName = (LPWSTR)pEveryoneSid;

        PACL pDacl = NULL;
        DWORD dwRes = SetEntriesInAclW(2, ea, NULL, &pDacl);

        bool success = false;
        if (dwRes == ERROR_SUCCESS) {
            // Принудительно назначаем Owner = NT AUTHORITY\SYSTEM и устанавливаем строгий DACL
            dwRes = SetNamedSecurityInfoW(
                (LPWSTR)path.c_str(),
                SE_FILE_OBJECT,
                OWNER_SECURITY_INFORMATION | DACL_SECURITY_INFORMATION | PROTECTED_DACL_SECURITY_INFORMATION,
                pSystemSid, // Owner
                NULL,       // Group
                pDacl,      // DACL
                NULL        // SACL
            );
            success = (dwRes == ERROR_SUCCESS);
            LocalFree(pDacl);
        }

        FreeSid(pEveryoneSid);
        FreeSid(pSystemSid);
        return success;
    }

    QuarantineResult QuarantineManager::IsolateFile(const std::wstring& targetPath) {
        QuarantineResult res;

        // Защита от изоляции самого себя
        if (SelfProtection::IsSelfFile(targetPath)) {
            res.errorReason = L"Self-protection: Cannot isolate KristMr core binary";
            return res;
        }

        // Открываем безопасный хэндл файла
        HANDLE hFile = FileGuard::OpenSafeFile(
            targetPath,
            GENERIC_READ | GENERIC_WRITE | DELETE | WRITE_DAC | WRITE_OWNER,
            FILE_SHARE_READ,
            OPEN_EXISTING
        );

        if (hFile == INVALID_HANDLE_VALUE) {
            // Попробуем с базовыми правами на чтение и удаление
            hFile = FileGuard::OpenSafeFile(
                targetPath,
                GENERIC_READ | DELETE,
                FILE_SHARE_READ,
                OPEN_EXISTING
            );
        }

        if (hFile == INVALID_HANDLE_VALUE) {
            res.errorReason = L"Failed to open target file for quarantine: " + std::to_wstring(GetLastError());
            return res;
        }

        // Проверяем hardlinks и reparse point
        FileValidationResult val = FileGuard::ValidateFileHandle(hFile, targetPath);
        if (!val.isValid) {
            CloseHandle(hFile);
            res.errorReason = val.errorReason;
            return res;
        }

        std::wstring mainQuarDir = GetMainQuarantineDir();
        std::wstring targetVol = GetVolumeRoot(targetPath);
        std::wstring mainVol = GetVolumeRoot(mainQuarDir);

        // Имя для карантина (timestamp_filename.locked)
        auto now = std::chrono::system_clock::now().time_since_epoch();
        uint64_t ts = std::chrono::duration_cast<std::chrono::milliseconds>(now).count();
        fs::path p(targetPath);
        std::wstring destFileName = std::to_wstring(ts) + L"_" + p.filename().wstring() + L".locked";

        bool sameVolume = (_wcsicmp(targetVol.c_str(), mainVol.c_str()) == 0);

        if (sameVolume) {
            // 1. Same volume: Атомарное перемещение по хэндлу
            std::wstring destPath = mainQuarDir + L"\\" + destFileName;

            // Подготовка буфера FILE_RENAME_INFO
            size_t nameByteLen = destPath.length() * sizeof(wchar_t);
            size_t allocSize = sizeof(FILE_RENAME_INFO) + nameByteLen;
            std::vector<uint8_t> buffer(allocSize, 0);
            FILE_RENAME_INFO* renameInfo = reinterpret_cast<FILE_RENAME_INFO*>(buffer.data());

            renameInfo->Flags = FILE_RENAME_FLAG_REPLACE_IF_EXISTS | FILE_RENAME_FLAG_POSIX_SEMANTICS;
            renameInfo->RootDirectory = NULL;
            renameInfo->FileNameLength = static_cast<DWORD>(nameByteLen);
            memcpy(renameInfo->FileName, destPath.c_str(), nameByteLen);

            // Пробуем SetFileInformationByHandle с FileRenameInfoEx, при откате используем FileRenameInfo
            if (SetFileInformationByHandle(hFile, FileRenameInfoEx, renameInfo, static_cast<DWORD>(allocSize)) ||
                SetFileInformationByHandle(hFile, FileRenameInfo, renameInfo, static_cast<DWORD>(allocSize))) {
                CloseHandle(hFile);
                ApplyNtfsPrivilegeTrap(destPath);
                res.success = true;
                res.quarantinePath = destPath;
                return res;
            }
        }

        // 2. Cross-Volume Handling (разные диски или SetFileInformationByHandle не поддержан файловой системой)
        std::wstring crossVolDir = targetVol + L".KristMr_Quarantine";
        CreateDirectoryW(crossVolDir.c_str(), NULL);
        SetFileAttributesW(crossVolDir.c_str(), FILE_ATTRIBUTE_HIDDEN | FILE_ATTRIBUTE_SYSTEM);
        ApplyNtfsPrivilegeTrap(crossVolDir);

        std::wstring crossVolDest = crossVolDir + L"\\" + destFileName;

        // Потоковое чтение и перенос содержимого
        HANDLE hDest = CreateFileW(
            crossVolDest.c_str(),
            GENERIC_WRITE | WRITE_DAC | WRITE_OWNER,
            0,
            NULL,
            CREATE_ALWAYS,
            FILE_ATTRIBUTE_HIDDEN | FILE_ATTRIBUTE_READONLY,
            NULL
        );

        bool copySuccess = false;
        if (hDest != INVALID_HANDLE_VALUE) {
            SetFilePointer(hFile, 0, NULL, FILE_BEGIN);
            std::vector<uint8_t> chunk(64 * 1024);
            DWORD bytesRead = 0, bytesWritten = 0;
            copySuccess = true;

            while (ReadFile(hFile, chunk.data(), static_cast<DWORD>(chunk.size()), &bytesRead, NULL) && bytesRead > 0) {
                if (!WriteFile(hDest, chunk.data(), bytesRead, &bytesWritten, NULL) || bytesWritten != bytesRead) {
                    copySuccess = false;
                    break;
                }
            }
            CloseHandle(hDest);
        }

        if (copySuccess) {
            ApplyNtfsPrivilegeTrap(crossVolDest);

            // Безопасное обнуление и удаление оригинала
            SetFilePointer(hFile, 0, NULL, FILE_BEGIN);
            SetEndOfFile(hFile); // обнуление размера

            FILE_DISPOSITION_INFO_EX_LOCAL dispEx = { FILE_DISPOSITION_FLAG_DELETE | FILE_DISPOSITION_FLAG_POSIX_SEMANTICS };
            if (!SetFileInformationByHandle(hFile, FileDispositionInfoEx, &dispEx, sizeof(dispEx))) {
                FILE_DISPOSITION_INFO disp = { TRUE };
                SetFileInformationByHandle(hFile, FileDispositionInfo, &disp, sizeof(disp));
            }
            CloseHandle(hFile);

            res.success = true;
            res.quarantinePath = crossVolDest;
            return res;
        }

        CloseHandle(hFile);
        res.errorReason = L"Cross-volume quarantine copy failed";
        return res;
    }

}
