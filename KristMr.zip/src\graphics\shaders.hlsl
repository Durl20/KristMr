cbuffer ConstantBuffer : register(b0)
{
    matrix ProjectionMatrix;
    float4 CurrentColor;
    float Time;
    float Phase;
    float Feather;
    float Padding;
};

struct VS_INPUT
{
    float3 Position : POSITION;
    float2 UV : TEXCOORD0;
    float4 Color : COLOR;
    float Size : PSIZE;
};

struct PS_INPUT
{
    float4 Position : SV_POSITION;
    float2 UV : TEXCOORD0;
    float4 Color : COLOR;
    float Feather : PSIZE;
};

PS_INPUT VSMain(VS_INPUT input)
{
    PS_INPUT output;
    output.Position = mul(float4(input.Position, 1.0f), ProjectionMatrix);
    output.UV = input.UV;
    output.Color = input.Color;
    output.Feather = Feather;
    return output;
}

float4 PSMain(PS_INPUT input) : SV_TARGET
{
    // Субпиксельное сглаживание и Anti-Shimmering
    // Вычисляем радиальное расстояние от центра частицы (0.5, 0.5)
    float dist = length(input.UV - float2(0.5f, 0.5f)) * 2.0f;
    
    // Кубический smoothstep для гладкого контура частицы без ступенек и мерцания
    float alpha = smoothstep(1.0f, 1.0f - input.Feather, dist);
    
    float4 col = input.Color * CurrentColor;
    col.a *= alpha;
    
    // Premultiplied alpha для DirectComposition DXGI_ALPHA_MODE_PREMULTIPLIED
    col.rgb *= col.a;
    
    return col;
}
