#pragma once
#include "common.hpp"

namespace KristMr {

    // Шаблонный класс для compile-time шифрования строк XOR с плавающим ключом
    template <size_t N, uint8_t KeySeed = 0x5A>
    class ObfuscatedString {
    private:
        std::array<char, N> m_encrypted;

        static constexpr uint8_t ComputeKey(size_t index) {
            return static_cast<uint8_t>(KeySeed ^ (index * 0x37 + 0x1F));
        }

    public:
        constexpr ObfuscatedString(const char(&str)[N]) : m_encrypted{} {
            for (size_t i = 0; i < N; ++i) {
                m_encrypted[i] = str[i] ^ ComputeKey(i);
            }
        }

        // Расшифровка на стеке
        std::string Decrypt() const {
            std::string result(N - 1, '\0');
            for (size_t i = 0; i < N - 1; ++i) {
                result[i] = m_encrypted[i] ^ ComputeKey(i);
            }
            return result;
        }
    };

    // Макрос для создания обфусцированной строки
    #define OBFUSCATE_STR(str) (KristMr::ObfuscatedString<sizeof(str)>(str).Decrypt())

    // Маркеры Hard Veto (зашифрованы в бинарнике)
    namespace HardVetoMarkers {
        inline constexpr ObfuscatedString STRATUM_TCP("stratum+tcp://");
        inline constexpr ObfuscatedString STRATUM_SSL("stratum+ssl://");
        inline constexpr ObfuscatedString XMRIG("xmrig");
        inline constexpr ObfuscatedString CRYPTONIGHT("cryptonight");
        inline constexpr ObfuscatedString DISCORD_WEBHOOK("discord.com/api/webhooks/");
        inline constexpr ObfuscatedString TELEGRAM_BOT("api.telegram.org/bot");
        inline constexpr ObfuscatedString VIRTUAL_ALLOC_EX("VirtualAllocEx");
        inline constexpr ObfuscatedString WRITE_PROCESS_MEMORY("WriteProcessMemory");
        inline constexpr ObfuscatedString CREATE_REMOTE_THREAD("CreateRemoteThread");
    }

    // Класс самозащиты от самообнаружения
    class SelfProtection {
    public:
        static void Initialize() {
            s_selfPid = GetCurrentProcessId();

            wchar_t selfPathBuf[MAX_PATH];
            DWORD len = GetModuleFileNameW(NULL, selfPathBuf, MAX_PATH);
            if (len > 0) {
                s_selfPath = selfPathBuf;
                // Приведение к нижнему регистру для нечувствительного сравнения
                std::transform(s_selfPath.begin(), s_selfPath.end(), s_selfPath.begin(), ::towlower);
            }
        }

        static DWORD GetSelfPid() {
            return s_selfPid;
        }

        static bool IsSelfFile(const std::wstring& filePath) {
            if (s_selfPath.empty()) return false;
            std::wstring normalized = filePath;
            std::transform(normalized.begin(), normalized.end(), normalized.begin(), ::towlower);
            return normalized == s_selfPath;
        }

        static bool IsSelfPid(DWORD pid) {
            return pid == s_selfPid;
        }

    private:
        inline static DWORD s_selfPid = 0;
        inline static std::wstring s_selfPath = L"";
    };

}
