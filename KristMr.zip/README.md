# KristMr (FINAL PRODUCTION MASTER v2.1)

Высокопроизводительный автономный монитор безопасности и оптимизации ядра Windows.

## 📌 Архитектура и стек
- **Платформа**: Microsoft Windows (x86_64, Windows 10 build 19041+ / Windows 11)
- **Стек**: Нативный C++20 (MSVC v143), Win32 API, NT Native API, DirectX 11, DirectComposition
- **Форм-фактор**: Одиночный автономный исполняемый модуль (`KristMr.exe`)
- **Развертывание**: `%ProgramFiles%\KristMr\KristMr.exe`
- **Конфигурация**: `%ProgramData%\KristMr\config\`
- **Ресурсы**: RAM ~18–26 МБ, CPU 0.0% в играх и фоновом режиме

---

## 🛡️ Ключевые возможности

1. **Безопасность и защита от LPE**:
   - Открытие файлов строго с `FILE_FLAG_OPEN_REPARSE_POINT`
   - Исключение hardlink-атак (`nNumberOfLinks > 1`)
   - Валидация подмен Junction через `GetFinalPathNameByHandleW`
   - Cross-Volume изоляция карантина с наложением NTFS Privilege Trap (Owner: `NT AUTHORITY\SYSTEM`, `DENY FILE_EXECUTE` для `Everyone`)

2. **Эвристический сканер и Hard Veto**:
   - Зашифрованные в бинарнике маркеры (майнеры, вебхуки discord/telegram, инъекции памяти) с расшифровкой на стеке
   - Репутационная сверка через MalwareBazaar и VirusTotal (с лимитом частоты)
   - Поддержка белого списка (`whitelist.txt`) для утилит (unlocker, activator, patcher)

3. **Оптимизация системного ядра (Гипер-режим)**:
   - Системный таймер 0.5 мс (`ntdll!NtSetTimerResolution` + обход EcoQoS)
   - Умное управление питанием с авто-определением топологии процессора (Intel P+E Hybrid / AMD 3D V-Cache)
   - Однократная очистка Standby List (`NtSetSystemInformation`)
   - Сброс кэша DNS и отключение сетевого троттлинга мультимедиа
   - Game Focus с устранением залипания приоритетов и EcoQoS-троттлинг фоновых процессов из `blacklist.txt`

4. **DirectX 11 + DirectComposition Графика**:
   - Выделенный поток рендеринга (Worker Thread) с Delta Time (QPC)
   - Субпиксельное сглаживание и Anti-Shimmering через HLSL smoothstep
   - Фаза 0: Индикатор загрузки 5 точек по кривой Эрмита
   - Фаза 1: 3D октаэдр на дискретных частицах
   - Smart Game Sense: автоматический перевод рендера в 0 FPS во время игр

5. **Штатный жизненный цикл**:
   - Автоматический возврат оригинальной схемы электропитания, параметров реестра и таймера при выходе из приложения

---

## 🛠️ Сборка

Запустите `build.bat` из директории проекта или выполните:

```cmd
cmake -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release
```
