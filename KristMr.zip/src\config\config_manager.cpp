#include "config_manager.hpp"
#include "../security/installer.hpp"

namespace KristMr {

    std::wstring ConfigManager::GetConfigDir() {
        return GetProgramDataAppDir() + L"\\config";
    }

    void ConfigManager::Initialize() {
        EnsureConfigFilesExist();
        LoadSettings();
        LoadBlacklist();
        LoadWhitelist();
    }

    void ConfigManager::EnsureConfigFilesExist() {
        std::wstring cfgDir = GetConfigDir();
        CreateDirectoryW(GetProgramDataAppDir().c_str(), NULL);
        CreateDirectoryW(cfgDir.c_str(), NULL);

        // Накладываем строгий DACL (Администраторы - запись, пользователи - только чтение)
        Installer::ApplyStrictDataDacl(cfgDir);

        std::wstring settingsPath = cfgDir + L"\\settings.ini";
        std::wstring blacklistPath = cfgDir + L"\\blacklist.txt";
        std::wstring whitelistPath = cfgDir + L"\\whitelist.txt";

        // 1. settings.ini
        if (GetFileAttributesW(settingsPath.c_str()) == INVALID_FILE_ATTRIBUTES) {
            std::ofstream out(settingsPath);
            if (out.is_open()) {
                out << "[Settings]\n"
                    << "# ВНИМАНИЕ: ТОЛЬКО ДЛЯ ПРОДВИНУТЫХ ПОЛЬЗОВАТЕЛЕЙ!\n"
                    << "hyper_mode = True\n"
                    << "game_focus = True\n"
                    << "realtime_antivirus = True\n"
                    << "smart_unlocker_pass = True\n"
                    << "clean_temp_junk = True\n"
                    << "flush_dns = True\n"
                    << "timer_resolution_05ms = True\n"
                    << "single_purge_standby = True\n"
                    << "virustotal_api_key = \n";
                out.close();
            }
        }

        // 2. blacklist.txt
        if (GetFileAttributesW(blacklistPath.c_str()) == INVALID_FILE_ATTRIBUTES) {
            std::ofstream out(blacklistPath);
            if (out.is_open()) {
                out << "onedrive.exe\n"
                    << "epicgameslauncher.exe\n"
                    << "steamwebhelper.exe\n"
                    << "origin.exe\n"
                    << "cortana.exe\n"
                    << "skype.exe\n"
                    << "dropbox.exe\n"
                    << "microsoftedgeupdate.exe\n"
                    << "googleupdate.exe\n";
                out.close();
            }
        }

        // 3. whitelist.txt
        if (GetFileAttributesW(whitelistPath.c_str()) == INVALID_FILE_ATTRIBUTES) {
            std::ofstream out(whitelistPath);
            if (out.is_open()) {
                out << "unlocker\n"
                    << "bypass\n"
                    << "activator\n"
                    << "crack\n"
                    << "patch\n"
                    << "loader\n"
                    << "spoofer\n"
                    << "keygen\n";
                out.close();
            }
        }
    }

    static bool ParseBoolIni(const std::string& val) {
        std::string s = val;
        std::transform(s.begin(), s.end(), s.begin(), ::tolower);
        return (s == "true" || s == "1" || s == "yes");
    }

    void ConfigManager::LoadSettings() {
        std::wstring settingsPath = GetConfigDir() + L"\\settings.ini";
        std::ifstream in(settingsPath);
        if (!in.is_open()) return;

        std::string line;
        while (std::getline(in, line)) {
            // Убираем комментарии и пробелы
            auto commentPos = line.find('#');
            if (commentPos != std::string::npos) line = line.substr(0, commentPos);
            commentPos = line.find(';');
            if (commentPos != std::string::npos) line = line.substr(0, commentPos);

            auto eqPos = line.find('=');
            if (eqPos == std::string::npos) continue;

            std::string key = line.substr(0, eqPos);
            std::string val = line.substr(eqPos + 1);

            // Trim
            auto trim = [](std::string& str) {
                while (!str.empty() && (str.front() == ' ' || str.front() == '\t')) str.erase(str.begin());
                while (!str.empty() && (str.back() == ' ' || str.back() == '\t' || str.back() == '\r')) str.pop_back();
            };
            trim(key);
            trim(val);

            if (key == "hyper_mode") s_settings.hyper_mode = ParseBoolIni(val);
            else if (key == "game_focus") s_settings.game_focus = ParseBoolIni(val);
            else if (key == "realtime_antivirus") s_settings.realtime_antivirus = ParseBoolIni(val);
            else if (key == "smart_unlocker_pass") s_settings.smart_unlocker_pass = ParseBoolIni(val);
            else if (key == "clean_temp_junk") s_settings.clean_temp_junk = ParseBoolIni(val);
            else if (key == "flush_dns") s_settings.flush_dns = ParseBoolIni(val);
            else if (key == "timer_resolution_05ms") s_settings.timer_resolution_05ms = ParseBoolIni(val);
            else if (key == "single_purge_standby") s_settings.single_purge_standby = ParseBoolIni(val);
            else if (key == "virustotal_api_key") s_settings.virustotal_api_key = val;
        }
    }

    void ConfigManager::LoadBlacklist() {
        std::wstring path = GetConfigDir() + L"\\blacklist.txt";
        std::wifstream in(path);
        if (!in.is_open()) return;

        s_blacklist.clear();
        std::wstring line;
        while (std::getline(in, line)) {
            while (!line.empty() && (line.back() == L'\r' || line.back() == L' ' || line.back() == L'\t')) line.pop_back();
            while (!line.empty() && (line.front() == L' ' || line.front() == L'\t')) line.erase(line.begin());
            if (!line.empty()) {
                s_blacklist.push_back(line);
            }
        }
    }

    void ConfigManager::LoadWhitelist() {
        std::wstring path = GetConfigDir() + L"\\whitelist.txt";
        std::wifstream in(path);
        if (!in.is_open()) return;

        s_whitelist.clear();
        std::wstring line;
        while (std::getline(in, line)) {
            while (!line.empty() && (line.back() == L'\r' || line.back() == L' ' || line.back() == L'\t')) line.pop_back();
            while (!line.empty() && (line.front() == L' ' || line.front() == L'\t')) line.erase(line.begin());
            if (!line.empty()) {
                s_whitelist.push_back(line);
            }
        }
    }

}
