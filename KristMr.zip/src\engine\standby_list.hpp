#pragma once
#include "../common.hpp"

namespace KristMr {

    class StandbyListManager {
    public:
        // Однократная безопасная очистка списка Standby List
        static bool PurgeStandbyListOnce();

    private:
        static bool EnableRequiredPrivileges();
        inline static std::atomic<bool> s_alreadyPurged{ false };
    };

}
