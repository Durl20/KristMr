#include "d3d_renderer.hpp"
#include "../vs_shader.h"
#include "../ps_shader.h"

namespace KristMr {

    D3DRenderer::D3DRenderer() {}

    D3DRenderer::~D3DRenderer() {
        Shutdown();
    }

    bool D3DRenderer::Initialize(HWND hWnd, int width, int height) {
        std::lock_guard<std::mutex> lock(m_resourceMutex);
        m_hWnd = hWnd;
        m_width = width;
        m_height = height;

        return CreateD3DResources();
    }

    void D3DRenderer::Shutdown() {
        StopRenderThread();
        ReleaseD3DResources();
    }

    void D3DRenderer::ReleaseD3DResources() {
        std::lock_guard<std::mutex> lock(m_resourceMutex);

        if (m_context) {
            m_context->ClearState();
        }

        m_depthStencilState.Reset();
        m_rasterizerState.Reset();
        m_blendState.Reset();
        m_constantBuffer.Reset();
        m_vertexBuffer.Reset();
        m_inputLayout.Reset();
        m_pixelShader.Reset();
        m_vertexShader.Reset();
        m_renderTargetView.Reset();
        m_swapChain.Reset();
        m_context.Reset();
        m_device.Reset();
    }

    bool D3DRenderer::CreateD3DResources() {
        UINT createDeviceFlags = 0;
#if defined(_DEBUG)
        createDeviceFlags |= D3D11_CREATE_DEVICE_DEBUG;
#endif

        D3D_FEATURE_LEVEL featureLevels[] = {
            D3D_FEATURE_LEVEL_11_1,
            D3D_FEATURE_LEVEL_11_0
        };
        D3D_FEATURE_LEVEL featureLevel;

        DXGI_SWAP_CHAIN_DESC scDesc = {};
        scDesc.BufferCount = 1;
        scDesc.BufferDesc.Width = m_width;
        scDesc.BufferDesc.Height = m_height;
        scDesc.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
        scDesc.BufferDesc.RefreshRate.Numerator = 60;
        scDesc.BufferDesc.RefreshRate.Denominator = 1;
        scDesc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
        scDesc.OutputWindow = m_hWnd;
        scDesc.SampleDesc.Count = 1;
        scDesc.SampleDesc.Quality = 0;
        scDesc.Windowed = TRUE;
        scDesc.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

        HRESULT hr = D3D11CreateDeviceAndSwapChain(
            NULL,
            D3D_DRIVER_TYPE_HARDWARE,
            NULL,
            createDeviceFlags,
            featureLevels,
            _countof(featureLevels),
            D3D11_SDK_VERSION,
            &scDesc,
            &m_swapChain,
            &m_device,
            &featureLevel,
            &m_context
        );

        if (FAILED(hr)) {
            hr = D3D11CreateDeviceAndSwapChain(
                NULL,
                D3D_DRIVER_TYPE_WARP,
                NULL,
                createDeviceFlags,
                featureLevels,
                _countof(featureLevels),
                D3D11_SDK_VERSION,
                &scDesc,
                &m_swapChain,
                &m_device,
                &featureLevel,
                &m_context
            );
            if (FAILED(hr)) return false;
        }

        // Render Target View
        ComPtr<ID3D11Texture2D> backBuffer;
        if (FAILED(m_swapChain->GetBuffer(0, IID_PPV_ARGS(&backBuffer)))) return false;

        hr = m_device->CreateRenderTargetView(backBuffer.Get(), NULL, &m_renderTargetView);
        if (FAILED(hr)) return false;

        // Шейдеры из байткода fxc
        hr = m_device->CreateVertexShader(g_VSMain, sizeof(g_VSMain), NULL, &m_vertexShader);
        if (FAILED(hr)) return false;

        hr = m_device->CreatePixelShader(g_PSMain, sizeof(g_PSMain), NULL, &m_pixelShader);
        if (FAILED(hr)) return false;

        // Input Layout
        D3D11_INPUT_ELEMENT_DESC layout[] = {
            { "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT,    0, 0,  D3D11_INPUT_PER_VERTEX_DATA, 0 },
            { "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT,       0, 12, D3D11_INPUT_PER_VERTEX_DATA, 0 },
            { "COLOR",    0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, 20, D3D11_INPUT_PER_VERTEX_DATA, 0 },
            { "PSIZE",    0, DXGI_FORMAT_R32_FLOAT,          0, 36, D3D11_INPUT_PER_VERTEX_DATA, 0 }
        };

        hr = m_device->CreateInputLayout(layout, _countof(layout), g_VSMain, sizeof(g_VSMain), &m_inputLayout);
        if (FAILED(hr)) return false;

        // Constant Buffer
        D3D11_BUFFER_DESC cbDesc = {};
        cbDesc.ByteWidth = sizeof(ConstantBufferData);
        cbDesc.Usage = D3D11_USAGE_DYNAMIC;
        cbDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
        cbDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;

        hr = m_device->CreateBuffer(&cbDesc, NULL, &m_constantBuffer);
        if (FAILED(hr)) return false;

        // Dynamic Vertex Buffer (до 24576 вершин)
        D3D11_BUFFER_DESC vbDesc = {};
        vbDesc.ByteWidth = sizeof(Vertex) * 24576;
        vbDesc.Usage = D3D11_USAGE_DYNAMIC;
        vbDesc.BindFlags = D3D11_BIND_VERTEX_BUFFER;
        vbDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;

        hr = m_device->CreateBuffer(&vbDesc, NULL, &m_vertexBuffer);
        if (FAILED(hr)) return false;

        // Rasterizer State: ОТКЛЮЧАЕМ BACKFACE CULLING!
        D3D11_RASTERIZER_DESC rsDesc = {};
        rsDesc.FillMode = D3D11_FILL_SOLID;
        rsDesc.CullMode = D3D11_CULL_NONE; // CULL_NONE гарантирует отображение абсолютно всех частиц
        rsDesc.FrontCounterClockwise = FALSE;
        rsDesc.DepthClipEnable = FALSE;

        hr = m_device->CreateRasterizerState(&rsDesc, &m_rasterizerState);
        if (FAILED(hr)) return false;

        // Depth Stencil State: отключаем тест глубины
        D3D11_DEPTH_STENCIL_DESC dsDesc = {};
        dsDesc.DepthEnable = FALSE;
        dsDesc.StencilEnable = FALSE;

        hr = m_device->CreateDepthStencilState(&dsDesc, &m_depthStencilState);
        if (FAILED(hr)) return false;

        // Blend State: альфа-смешивание частиц
        D3D11_BLEND_DESC blendDesc = {};
        blendDesc.RenderTarget[0].BlendEnable = TRUE;
        blendDesc.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA;
        blendDesc.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_ALPHA;
        blendDesc.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
        blendDesc.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
        blendDesc.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_INV_SRC_ALPHA;
        blendDesc.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
        blendDesc.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;

        hr = m_device->CreateBlendState(&blendDesc, &m_blendState);
        return SUCCEEDED(hr);
    }

    void D3DRenderer::SetTargetColorState(CrystalState state) {
        m_crystalState.store(state);
        m_attackTimer = 0.0f;

        switch (state) {
            case CrystalState::ThreatDetected:
                m_targetColor = COLOR_CRIMSON;
                break;
            case CrystalState::BypassAllowed:
                m_targetColor = COLOR_EMERALD;
                break;
            case CrystalState::QuarantineAlert:
                m_targetColor = COLOR_AMBER;
                break;
            default:
                m_targetColor = COLOR_AZURE;
                break;
        }
    }

    void D3DRenderer::SetMinimizedToTray(bool minimized) {
        m_minimizedToTray.store(minimized);
    }

    void D3DRenderer::ResizeBuffers(int newWidth, int newHeight) {
        if (newWidth <= 0 || newHeight <= 0) return;
        m_pendingWidth = newWidth;
        m_pendingHeight = newHeight;
        m_needsResize.store(true);
    }

    void D3DRenderer::AdjustGlobalAlpha(float delta) {
        float cur = m_globalAlpha.load();
        float updated = std::clamp(cur + delta, 0.35f, 1.0f);
        m_globalAlpha.store(updated);
    }

    void D3DRenderer::UpdateColorTransitions(float dt) {
        if (m_crystalState.load() != CrystalState::HyperActive) {
            m_attackTimer += dt;
            if (m_attackTimer > 0.06f) {
                float decayRate = 1.9f;
                float factor = std::exp(-decayRate * dt);
                m_currentColor.r = COLOR_AZURE.r + (m_currentColor.r - COLOR_AZURE.r) * factor;
                m_currentColor.g = COLOR_AZURE.g + (m_currentColor.g - COLOR_AZURE.g) * factor;
                m_currentColor.b = COLOR_AZURE.b + (m_currentColor.b - COLOR_AZURE.b) * factor;

                if (std::abs(m_currentColor.r - COLOR_AZURE.r) < 0.02f &&
                    std::abs(m_currentColor.g - COLOR_AZURE.g) < 0.02f &&
                    std::abs(m_currentColor.b - COLOR_AZURE.b) < 0.02f) {
                    m_crystalState.store(CrystalState::HyperActive);
                    m_currentColor = COLOR_AZURE;
                }
            } else {
                float t = m_attackTimer / 0.06f;
                m_currentColor.r = m_currentColor.r + (m_targetColor.r - m_currentColor.r) * t;
                m_currentColor.g = m_currentColor.g + (m_targetColor.g - m_currentColor.g) * t;
                m_currentColor.b = m_currentColor.b + (m_targetColor.b - m_currentColor.b) * t;
            }
        } else {
            m_currentColor = COLOR_AZURE;
        }
    }

    void D3DRenderer::RenderFrame(float dt) {
        std::lock_guard<std::mutex> lock(m_resourceMutex);
        if (!m_context || !m_swapChain || !m_renderTargetView) return;

        if (m_needsResize.exchange(false)) {
            m_context->OMSetRenderTargets(0, NULL, NULL);
            m_renderTargetView.Reset();

            m_width = m_pendingWidth;
            m_height = m_pendingHeight;

            if (SUCCEEDED(m_swapChain->ResizeBuffers(0, m_width, m_height, DXGI_FORMAT_UNKNOWN, 0))) {
                ComPtr<ID3D11Texture2D> backBuffer;
                if (SUCCEEDED(m_swapChain->GetBuffer(0, IID_PPV_ARGS(&backBuffer)))) {
                    m_device->CreateRenderTargetView(backBuffer.Get(), NULL, &m_renderTargetView);
                }
            }
        }

        m_totalTime += dt;
        m_rotY += 1.25f * dt; // Непрерывное вращение кристалла

        UpdateColorTransitions(dt);

        // Черный глубокий фон (0.03, 0.04, 0.06) как на фото
        float clearColor[4] = { 0.03f, 0.04f, 0.06f, 1.0f };
        m_context->ClearRenderTargetView(m_renderTargetView.Get(), clearColor);

        // Построение вершин ромба и ядра в координатах NDC
        std::vector<Vertex> vertices;
        m_model.BuildFrameVertices(m_totalTime, m_rotY, vertices, m_width, m_height);

        if (vertices.empty()) return;

        // Копирование в Dynamic Vertex Buffer
        D3D11_MAPPED_SUBRESOURCE mappedVb;
        if (SUCCEEDED(m_context->Map(m_vertexBuffer.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedVb))) {
            size_t copyBytes = std::min(sizeof(Vertex) * vertices.size(), static_cast<size_t>(sizeof(Vertex) * 24576));
            memcpy(mappedVb.pData, vertices.data(), copyBytes);
            m_context->Unmap(m_vertexBuffer.Get(), 0);
        }

        // Constant Buffer
        D3D11_MAPPED_SUBRESOURCE mappedCb;
        if (SUCCEEDED(m_context->Map(m_constantBuffer.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedCb))) {
            ConstantBufferData* cb = reinterpret_cast<ConstantBufferData*>(mappedCb.pData);
            cb->currentColor[0] = m_currentColor.r;
            cb->currentColor[1] = m_currentColor.g;
            cb->currentColor[2] = m_currentColor.b;
            cb->currentColor[3] = m_currentColor.a;
            cb->time = m_totalTime;
            cb->globalAlpha = m_globalAlpha.load();
            cb->feather = 0.35f;
            cb->padding = 0.0f;
            m_context->Unmap(m_constantBuffer.Get(), 0);
        }

        // Viewport
        D3D11_VIEWPORT vp = {};
        vp.Width = static_cast<float>(m_width);
        vp.Height = static_cast<float>(m_height);
        vp.MinDepth = 0.0f;
        vp.MaxDepth = 1.0f;
        m_context->RSSetViewports(1, &vp);

        // Настройка графического конвейера
        ID3D11RenderTargetView* rtvList[] = { m_renderTargetView.Get() };
        m_context->OMSetRenderTargets(1, rtvList, NULL);

        // Устанавливаем отключение отсечения и глубины
        m_context->RSSetState(m_rasterizerState.Get());
        m_context->OMSetDepthStencilState(m_depthStencilState.Get(), 0);

        float blendFactor[4] = { 0, 0, 0, 0 };
        m_context->OMSetBlendState(m_blendState.Get(), blendFactor, 0xFFFFFFFF);

        m_context->IASetInputLayout(m_inputLayout.Get());
        m_context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

        UINT stride = sizeof(Vertex);
        UINT offset = 0;
        ID3D11Buffer* vbs[] = { m_vertexBuffer.Get() };
        m_context->IASetVertexBuffers(0, 1, vbs, &stride, &offset);

        m_context->VSSetShader(m_vertexShader.Get(), NULL, 0);
        ID3D11Buffer* cbs[] = { m_constantBuffer.Get() };
        m_context->VSSetConstantBuffers(0, 1, cbs);

        m_context->PSSetShader(m_pixelShader.Get(), NULL, 0);
        m_context->PSSetConstantBuffers(0, 1, cbs);

        // Отрисовка
        m_context->Draw(static_cast<UINT>(vertices.size()), 0);
    }

    void D3DRenderer::RenderLoop() {
        SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_HIGHEST);

        LARGE_INTEGER qpcFreq = {}, lastQpc = {}, curQpc = {};
        QueryPerformanceFrequency(&qpcFreq);
        QueryPerformanceCounter(&lastQpc);

        while (m_running) {
            if (m_minimizedToTray.load() || GameSense::IsGameRunning()) {
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
                QueryPerformanceCounter(&lastQpc);
                continue;
            }

            QueryPerformanceCounter(&curQpc);
            double dt = static_cast<double>(curQpc.QuadPart - lastQpc.QuadPart) / static_cast<double>(qpcFreq.QuadPart);
            lastQpc = curQpc;

            if (dt > 0.1) dt = 0.016;

            RenderFrame(static_cast<float>(dt));

            if (m_swapChain) {
                m_swapChain->Present(1, 0);
            }
        }
    }

    void D3DRenderer::StartRenderThread() {
        if (m_running) return;
        m_running = true;
        m_renderThread = std::thread(&D3DRenderer::RenderLoop, this);
    }

    void D3DRenderer::StopRenderThread() {
        if (!m_running) return;
        m_running = false;
        if (m_renderThread.joinable()) {
            m_renderThread.join();
        }
    }

}
