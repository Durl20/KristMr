#pragma once
#include "../common.hpp"
#include "pe_parser.hpp"
#include "reputation.hpp"
#include "../security/quarantine.hpp"

namespace KristMr {

    using StateChangeCallback = std::function<void(CrystalState, const std::wstring& filePath, const std::string& reason)>;

    struct WatcherContext {
        OVERLAPPED overlapped = {};
        HANDLE hDir = INVALID_HANDLE_VALUE;
        std::wstring dirPath = L"";
        std::vector<uint8_t> buffer;
    };

    class DirectoryWatcher {
    public:
        DirectoryWatcher();
        ~DirectoryWatcher();

        bool Start(const std::vector<std::wstring>& whitelist, StateChangeCallback stateCallback);
        void Stop();

    private:
        void WorkerThread();
        void RegisterWatchDirectory(const std::wstring& path);
        void ProcessFile(const std::wstring& filePath);
        bool WaitForFileWriteComplete(const std::wstring& filePath);
        void PerformDifferentialScan(const std::wstring& dirPath);

        std::vector<std::wstring> m_whitelist;
        StateChangeCallback m_stateCallback;

        HANDLE m_hIocp = NULL;
        std::vector<std::unique_ptr<WatcherContext>> m_contexts;
        std::thread m_workerThread;
        std::atomic<bool> m_running{ false };
    };

}
