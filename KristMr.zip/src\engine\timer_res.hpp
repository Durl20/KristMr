#pragma once
#include "../common.hpp"

namespace KristMr {

    class TimerResolutionManager {
    public:
        // Активация разрешения таймера 0.5 мс и обход EcoQoS
        static bool EnableHighResolutionTimer();

        // Восстановление системного таймера
        static void RestoreTimerResolution();

        static bool IsActive() { return s_isActive; }

    private:
        inline static std::atomic<bool> s_isActive{ false };
        inline static ULONG s_currentRes = 0;
        inline static pfnNtSetTimerResolution s_pfnNtSetTimerResolution = nullptr;
    };

}
