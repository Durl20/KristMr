#pragma once
#include "../common.hpp"
#include <list>

namespace KristMr {

    enum class ReputationStatus {
        Unknown,   // Неизвестен
        Malicious, // Вредоносный (MalwareBazaar или VT > 3)
        Safe,      // Безопасный
        Offline    // Сеть недоступна
    };

    class ReputationScanner {
    public:
        static void Initialize(const std::string& vtApiKey);

        // Проверка репутации по хэшу SHA-256
        static ReputationStatus QueryHashReputation(const std::string& sha256);

    private:
        // Проверка LRU кэша
        static bool CheckLruCache(const std::string& sha256, ReputationStatus& outStatus);
        static void UpdateLruCache(const std::string& sha256, ReputationStatus status);

        // Запросы к внешним API
        static ReputationStatus QueryMalwareBazaar(const std::string& sha256);
        static ReputationStatus QueryVirusTotal(const std::string& sha256);

        // Вспомогательный HTTP POST/GET через WinHTTP
        static std::string HttpPost(const std::wstring& host, const std::wstring& path, const std::string& postData, const std::wstring& headers);
        static std::string HttpGet(const std::wstring& host, const std::wstring& path, const std::wstring& headers);

        inline static std::string s_vtApiKey = "";
        inline static std::mutex s_cacheMutex;
        inline static std::list<std::pair<std::string, ReputationStatus>> s_lruList;
        inline static std::unordered_map<std::string, std::list<std::pair<std::string, ReputationStatus>>::iterator> s_lruMap;
        static constexpr size_t LRU_CAPACITY = 2048;

        // Rate limiter для VirusTotal (1 запрос в 15 сек, макс 500 в сутки)
        inline static std::chrono::steady_clock::time_point s_lastVtRequestTime = std::chrono::steady_clock::time_point::min();
        inline static int s_vtDailyCount = 0;
        inline static std::chrono::system_clock::time_point s_vtDailyResetTime = std::chrono::system_clock::now();
        inline static std::mutex s_vtRateMutex;
    };

}
