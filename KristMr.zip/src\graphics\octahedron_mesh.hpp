#pragma once
#include "../common.hpp"

namespace KristMr {

    struct Vertex {
        float x, y, z;
        float u, v;
        float r, g, b, a;
        float size;
    };

    struct Point3D {
        float x, y, z;
        float size;
        float baseAlpha;
        float isCore;
    };

    class OctahedronModel {
    public:
        OctahedronModel() {
            GenerateGeometry();
        }

        void BuildFrameVertices(float time,
                                float rotYRad,
                                std::vector<Vertex>& outVertices,
                                int screenW,
                                int screenH) {
            outVertices.clear();

            if (screenW <= 0 || screenH <= 0) return;

            float aspect = static_cast<float>(screenW) / static_cast<float>(screenH);
            const float tiltXRad = 18.0f * (3.1415926535f / 180.0f); // 18 градусов наклон по X
            const float camDist = 2.4f;

            float cosX = std::cos(tiltXRad), sinX = std::sin(tiltXRad);
            float cosY = std::cos(rotYRad), sinY = std::sin(rotYRad);

            struct ProjectedPoint {
                float ndcX, ndcY, ndcZ;
                float sizePx;
                float brightness;
                float alpha;
            };

            std::vector<ProjectedPoint> projected;
            projected.reserve(m_points.size());

            for (const auto& pt : m_points) {
                float currentSize = pt.size;
                float currentAlpha = pt.baseAlpha;

                // Пульсация внутреннего ядра
                if (pt.isCore > 0.5f) {
                    float pulse = std::sin(time * 3.5f + pt.y * 6.0f) * 0.5f;
                    currentSize += pulse;
                }

                // 1. Вращение вокруг оси Y
                float x1 = pt.x * cosY + pt.z * sinY;
                float y1 = pt.y;
                float z1 = -pt.x * sinY + pt.z * cosY;

                // 2. Наклон вокруг оси X (18 градусов)
                float x2 = x1;
                float y2 = y1 * cosX - z1 * sinX;
                float z2 = y1 * sinX + z1 * cosX;

                // 3. Перспективная проекция
                float zCam = camDist + z2;
                if (zCam > 0.1f) {
                    float factor = camDist / zCam;

                    // Нормализованные координаты устройства NDC [-1, 1]
                    float ndcX = (x2 * factor) / aspect;
                    float ndcY = y2 * factor;
                    float ndcZ = z2 * 0.5f + 0.5f;

                    // Затенение по глубине Z
                    float depthNorm = (z2 + 0.4f) / 0.8f;
                    depthNorm = std::clamp(depthNorm, 0.0f, 1.0f);
                    float brightness = 0.70f + 0.30f * depthNorm;

                    projected.push_back({ ndcX, ndcY, zCam, currentSize, brightness, currentAlpha });
                }
            }

            // 4. Z-сортировка от дальних к ближним
            std::sort(projected.begin(), projected.end(), [](const ProjectedPoint& a, const ProjectedPoint& b) {
                return a.ndcZ > b.ndcZ;
            });

            // 5. Построение билбордов с правильным CW winding order
            for (const auto& p : projected) {
                float rx = (p.sizePx / static_cast<float>(screenW));
                float ry = (p.sizePx / static_cast<float>(screenH));

                float xLeft  = p.ndcX - rx;
                float xRight = p.ndcX + rx;
                float yTop   = p.ndcY + ry;
                float yBot   = p.ndcY - ry;

                // Вершины:
                // A: верх-лево  (xLeft, yTop)
                // B: верх-право (xRight, yTop)
                // C: низ-лево   (xLeft, yBot)
                // D: низ-право  (xRight, yBot)

                // Треугольник 1 (CW): A -> B -> C
                outVertices.push_back({ xLeft,  yTop, 0.0f, 0.0f, 0.0f, p.brightness, p.brightness, p.brightness, p.alpha, p.sizePx });
                outVertices.push_back({ xRight, yTop, 0.0f, 1.0f, 0.0f, p.brightness, p.brightness, p.brightness, p.alpha, p.sizePx });
                outVertices.push_back({ xLeft,  yBot, 0.0f, 0.0f, 1.0f, p.brightness, p.brightness, p.brightness, p.alpha, p.sizePx });

                // Треугольник 2 (CW): B -> D -> C
                outVertices.push_back({ xRight, yTop, 0.0f, 1.0f, 0.0f, p.brightness, p.brightness, p.brightness, p.alpha, p.sizePx });
                outVertices.push_back({ xRight, yBot, 0.0f, 1.0f, 1.0f, p.brightness, p.brightness, p.brightness, p.alpha, p.sizePx });
                outVertices.push_back({ xLeft,  yBot, 0.0f, 0.0f, 1.0f, p.brightness, p.brightness, p.brightness, p.alpha, p.sizePx });
            }
        }

    private:
        void GenerateGeometry() {
            m_points.clear();

            // Вытянутый 3D-октаэдр:
            // Пики ±0.76, радиус экватора 0.30
            const float peakY = 0.76f;
            const float eqRadius = 0.30f;

            const Point3D topVertex    = {  0.0f,      peakY,  0.0f,      6.2f, 1.0f, 0.0f };
            const Point3D bottomVertex = {  0.0f,     -peakY,  0.0f,      6.2f, 1.0f, 0.0f };
            const Point3D eqVertices[4] = {
                {  eqRadius, 0.0f,  0.0f,      5.5f, 1.0f, 0.0f },
                { -eqRadius, 0.0f,  0.0f,      5.5f, 1.0f, 0.0f },
                {  0.0f,     0.0f,  eqRadius,  5.5f, 1.0f, 0.0f },
                {  0.0f,     0.0f, -eqRadius,  5.5f, 1.0f, 0.0f }
            };

            m_points.push_back(topVertex);
            m_points.push_back(bottomVertex);
            for (int i = 0; i < 4; ++i) {
                m_points.push_back(eqVertices[i]);
            }

            // 1. 12 ребер октаэдра (плотные цепочки квантовых точек)
            std::vector<std::pair<Point3D, Point3D>> mainEdges;
            for (int i = 0; i < 4; ++i) {
                mainEdges.push_back({ topVertex, eqVertices[i] });
                mainEdges.push_back({ bottomVertex, eqVertices[i] });
            }
            mainEdges.push_back({ eqVertices[0], eqVertices[2] });
            mainEdges.push_back({ eqVertices[2], eqVertices[1] });
            mainEdges.push_back({ eqVertices[1], eqVertices[3] });
            mainEdges.push_back({ eqVertices[3], eqVertices[0] });

            for (const auto& edge : mainEdges) {
                const int steps = 30;
                for (int s = 1; s < steps; ++s) {
                    float t = static_cast<float>(s) / static_cast<float>(steps);
                    float x = edge.first.x + (edge.second.x - edge.first.x) * t;
                    float y = edge.first.y + (edge.second.y - edge.first.y) * t;
                    float z = edge.first.z + (edge.second.z - edge.first.z) * t;
                    m_points.push_back({ x, y, z, 4.5f, 0.98f, 0.0f });
                }
            }

            // 2. Горизонтальные сеточные кольца на гранях
            const int levels = 14;
            for (int lvl = 1; lvl <= levels; ++lvl) {
                float t = static_cast<float>(lvl) / static_cast<float>(levels + 1);

                float yTop = peakY * (1.0f - t);
                float rTop = eqRadius * t;

                float yBot = -peakY * (1.0f - t);
                float rBot = eqRadius * t;

                Point3D ringTop[4] = {
                    {  rTop, yTop,  0.0f, 3.6f, 0.90f, 0.0f },
                    {  0.0f, yTop,  rTop, 3.6f, 0.90f, 0.0f },
                    { -rTop, yTop,  0.0f, 3.6f, 0.90f, 0.0f },
                    {  0.0f, yTop, -rTop, 3.6f, 0.90f, 0.0f }
                };

                Point3D ringBot[4] = {
                    {  rBot, yBot,  0.0f, 3.6f, 0.90f, 0.0f },
                    {  0.0f, yBot,  rBot, 3.6f, 0.90f, 0.0f },
                    { -rBot, yBot,  0.0f, 3.6f, 0.90f, 0.0f },
                    {  0.0f, yBot, -rBot, 3.6f, 0.90f, 0.0f }
                };

                int ptsPerSide = std::max(2, static_cast<int>(t * 7.0f));

                for (int side = 0; side < 4; ++side) {
                    int nextSide = (side + 1) % 4;
                    for (int p = 1; p < ptsPerSide; ++p) {
                        float frac = static_cast<float>(p) / static_cast<float>(ptsPerSide);

                        float xt = ringTop[side].x + (ringTop[nextSide].x - ringTop[side].x) * frac;
                        float zt = ringTop[side].z + (ringTop[nextSide].z - ringTop[side].z) * frac;
                        m_points.push_back({ xt, yTop, zt, 3.4f, 0.85f, 0.0f });

                        float xb = ringBot[side].x + (ringBot[nextSide].x - ringBot[side].x) * frac;
                        float zb = ringBot[side].z + (ringBot[nextSide].z - ringBot[side].z) * frac;
                        m_points.push_back({ xb, yBot, zb, 3.4f, 0.85f, 0.0f });
                    }
                }
            }

            // 3. Внутреннее светящееся квантовое ядро (вертикальный жгут в центре)
            const int corePointsCount = 120;
            for (int i = 0; i < corePointsCount; ++i) {
                float norm = static_cast<float>(i) / static_cast<float>(corePointsCount - 1);
                float y = -0.28f + 0.56f * norm;

                float envelope = 1.0f - (std::abs(y) / 0.32f);
                envelope = std::max(0.1f, envelope);
                float r = 0.03f + 0.05f * envelope;

                float angle = static_cast<float>(i) * 0.44f;
                float cx = r * std::cos(angle);
                float cz = r * std::sin(angle);

                m_points.push_back({ cx, y, cz, 5.2f, 1.0f, 1.0f });
            }
        }

        std::vector<Point3D> m_points;
    };

}
