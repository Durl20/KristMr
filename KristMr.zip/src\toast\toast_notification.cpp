#include "toast_notification.hpp"

namespace KristMr {

    void ToastNotification::Initialize() {
        SetCurrentProcessExplicitAppUserModelID(APP_USER_MODEL_ID);
    }

    void ToastNotification::ShowToast(const std::wstring& title, const std::wstring& message, HWND hWndFallback) {
        if (hWndFallback) {
            NOTIFYICONDATAW nid = {};
            nid.cbSize = sizeof(nid);
            nid.hWnd = hWndFallback;
            nid.uID = 1001;
            nid.uFlags = NIF_INFO;
            nid.dwInfoFlags = NIIF_INFO | NIIF_LARGE_ICON;
            wcsncpy_s(nid.szInfoTitle, title.c_str(), _TRUNCATE);
            wcsncpy_s(nid.szInfo, message.c_str(), _TRUNCATE);

            Shell_NotifyIconW(NIM_MODIFY, &nid);
        }
    }

}
