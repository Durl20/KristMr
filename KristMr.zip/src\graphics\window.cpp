#include "window.hpp"

#define WM_TRAYICON_MSG (WM_APP + 100)
#define ID_TRAY_SHOW 101
#define ID_TRAY_EXIT 102

namespace KristMr {

    MainWindow::MainWindow() {}

    MainWindow::~MainWindow() {
        RemoveTrayIcon();
        m_renderer.Shutdown();
    }

    LRESULT CALLBACK MainWindow::WndProcStatic(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
        MainWindow* self = nullptr;
        if (msg == WM_NCCREATE) {
            CREATESTRUCT* cs = reinterpret_cast<CREATESTRUCT*>(lParam);
            self = reinterpret_cast<MainWindow*>(cs->lpCreateParams);
            SetWindowLongPtrW(hWnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(self));
        } else {
            self = reinterpret_cast<MainWindow*>(GetWindowLongPtrW(hWnd, GWLP_USERDATA));
        }

        if (self) {
            return self->WndProc(hWnd, msg, wParam, lParam);
        }
        return DefWindowProcW(hWnd, msg, wParam, lParam);
    }

    LRESULT MainWindow::WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
        switch (msg) {
            case WM_PAINT: {
                PAINTSTRUCT ps;
                BeginPaint(hWnd, &ps);
                EndPaint(hWnd, &ps);
                return 0;
            }

            case WM_ERASEBKGND:
                return 1;

            case WM_SIZE: {
                int newW = LOWORD(lParam);
                int newH = HIWORD(lParam);
                if (wParam != SIZE_MINIMIZED && newW > 0 && newH > 0) {
                    m_currentWidth = newW;
                    m_currentHeight = newH;
                    m_renderer.ResizeBuffers(newW, newH);
                }
                return 0;
            }

            case WM_MOUSEWHEEL: {
                short wheelDelta = GET_WHEEL_DELTA_WPARAM(wParam);
                m_renderer.AdjustGlobalAlpha(wheelDelta > 0 ? 0.05f : -0.05f);
                return 0;
            }

            case WM_RBUTTONUP: {
                POINT pt;
                GetCursorPos(&pt);
                ShowTrayContextMenu(pt.x, pt.y);
                return 0;
            }

            case WM_TRAYICON_MSG: {
                if (LOWORD(lParam) == WM_LBUTTONUP) {
                    RestoreFromTray();
                } else if (LOWORD(lParam) == WM_RBUTTONUP) {
                    POINT pt;
                    GetCursorPos(&pt);
                    ShowTrayContextMenu(pt.x, pt.y);
                }
                return 0;
            }

            case WM_CLOSE: {
                // Прячем в трей при нажатии крестика
                HideToTray();
                return 0;
            }

            case WM_DESTROY: {
                PostQuitMessage(0);
                return 0;
            }

            default:
                break;
        }
        return DefWindowProcW(hWnd, msg, wParam, lParam);
    }

    bool MainWindow::Create(HINSTANCE hInstance) {
        m_hInstance = hInstance;

        WNDCLASSEXW wc = {};
        wc.cbSize = sizeof(wc);
        wc.style = CS_HREDRAW | CS_VREDRAW;
        wc.lpfnWndProc = MainWindow::WndProcStatic;
        wc.hInstance = hInstance;
        wc.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(101));
        wc.hIconSm = LoadIcon(hInstance, MAKEINTRESOURCE(101));
        wc.hCursor = LoadCursor(NULL, IDC_ARROW);
        wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
        wc.lpszClassName = L"KristMr_MainWindow_Class";

        RegisterClassExW(&wc);

        // Стандартный стиль окна с рамками и заголовком
        DWORD dwStyle = WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX | WS_THICKFRAME;

        RECT rc = { 0, 0, m_currentWidth, m_currentHeight };
        AdjustWindowRect(&rc, dwStyle, FALSE);

        int winW = rc.right - rc.left;
        int winH = rc.bottom - rc.top;

        int screenW = GetSystemMetrics(SM_CXSCREEN);
        int screenH = GetSystemMetrics(SM_CYSCREEN);
        int posX = (screenW - winW) / 2;
        int posY = (screenH - winH) / 2;

        m_hWnd = CreateWindowExW(
            WS_EX_APPWINDOW,
            wc.lpszClassName,
            L"KristMr - Security & Engine Optimizer",
            dwStyle,
            posX, posY,
            winW, winH,
            NULL, NULL, hInstance, this
        );

        if (!m_hWnd) return false;

        // Инициализация DirectX 11 рендерера
        if (!m_renderer.Initialize(m_hWnd, m_currentWidth, m_currentHeight)) {
            return false;
        }

        m_renderer.StartRenderThread();
        return true;
    }

    void MainWindow::Show() {
        ShowWindow(m_hWnd, SW_SHOWNORMAL);
        UpdateWindow(m_hWnd);
    }

    void MainWindow::HideToTray() {
        if (!m_inTray) {
            AddTrayIcon();
            ShowWindow(m_hWnd, SW_HIDE);
            m_renderer.SetMinimizedToTray(true);
            m_inTray = true;
        }
    }

    void MainWindow::RestoreFromTray() {
        if (m_inTray) {
            ShowWindow(m_hWnd, SW_SHOWNORMAL);
            SetForegroundWindow(m_hWnd);
            m_renderer.SetMinimizedToTray(false);
            RemoveTrayIcon();
            m_inTray = false;
        }
    }

    void MainWindow::AddTrayIcon() {
        m_nid.cbSize = sizeof(m_nid);
        m_nid.hWnd = m_hWnd;
        m_nid.uID = 1001;
        m_nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
        m_nid.uCallbackMessage = WM_TRAYICON_MSG;
        m_nid.hIcon = LoadIcon(m_hInstance, MAKEINTRESOURCE(101));
        if (!m_nid.hIcon) m_nid.hIcon = LoadIcon(NULL, IDI_SHIELD);
        wcsncpy_s(m_nid.szTip, L"KristMr Hyper-Security Monitor", _countof(m_nid.szTip));

        Shell_NotifyIconW(NIM_ADD, &m_nid);
    }

    void MainWindow::RemoveTrayIcon() {
        if (m_nid.hWnd) {
            Shell_NotifyIconW(NIM_DELETE, &m_nid);
            m_nid.hWnd = NULL;
        }
    }

    void MainWindow::ShowTrayContextMenu(int x, int y) {
        HMENU hMenu = CreatePopupMenu();
        AppendMenuW(hMenu, MF_STRING, ID_TRAY_SHOW, L"Показать KristMr");
        AppendMenuW(hMenu, MF_SEPARATOR, 0, NULL);
        AppendMenuW(hMenu, MF_STRING, ID_TRAY_EXIT, L"Выход");

        SetForegroundWindow(m_hWnd);
        int cmd = TrackPopupMenuEx(hMenu, TPM_RETURNCMD | TPM_RIGHTBUTTON, x, y, m_hWnd, NULL);
        DestroyMenu(hMenu);

        if (cmd == ID_TRAY_SHOW) {
            RestoreFromTray();
        } else if (cmd == ID_TRAY_EXIT) {
            RemoveTrayIcon();
            DestroyWindow(m_hWnd);
        }
    }

}
