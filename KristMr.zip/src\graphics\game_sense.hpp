#pragma once
#include "../common.hpp"

namespace KristMr {

    class GameSense {
    public:
        static void Start();
        static void Stop();

        static bool IsGameRunning() {
            return s_isGameRunning.load();
        }

    private:
        static void MonitorThread();
        static bool CheckFullScreenGame();

        inline static std::atomic<bool> s_running{ false };
        inline static std::atomic<bool> s_isGameRunning{ false };
        inline static std::thread s_thread;
    };

}
