#include "pe_parser.hpp"
#include "../obfuscation.hpp"
#include "../security/file_guard.hpp"
#include <wincrypt.h>

namespace KristMr {

    std::string PeParser::ComputeSha256(const std::vector<uint8_t>& fileData) {
        if (fileData.empty()) return "";

        HCRYPTPROV hProv = 0;
        HCRYPTHASH hHash = 0;
        std::string hexResult = "";

        if (CryptAcquireContextW(&hProv, NULL, NULL, PROV_RSA_AES, CRYPT_VERIFYCONTEXT)) {
            if (CryptCreateHash(hProv, CALG_SHA_256, 0, 0, &hHash)) {
                if (CryptHashData(hHash, fileData.data(), static_cast<DWORD>(fileData.size()), 0)) {
                    BYTE hashBuf[32] = {};
                    DWORD hashLen = sizeof(hashBuf);
                    if (CryptGetHashParam(hHash, HP_HASHVAL, hashBuf, &hashLen, 0)) {
                        char hexDigits[] = "0123456789abcdef";
                        hexResult.reserve(64);
                        for (DWORD i = 0; i < hashLen; ++i) {
                            hexResult.push_back(hexDigits[(hashBuf[i] >> 4) & 0x0F]);
                            hexResult.push_back(hexDigits[hashBuf[i] & 0x0F]);
                        }
                    }
                }
                CryptDestroyHash(hHash);
            }
            CryptReleaseContext(hProv, 0);
        }

        return hexResult;
    }

    bool PeParser::ValidatePeStructure(const uint8_t* data, size_t size) {
        if (size < sizeof(IMAGE_DOS_HEADER)) return false;

        const IMAGE_DOS_HEADER* dosHeader = reinterpret_cast<const IMAGE_DOS_HEADER*>(data);
        if (dosHeader->e_magic != IMAGE_DOS_SIGNATURE) return false;

        if (dosHeader->e_lfanew <= 0 || static_cast<size_t>(dosHeader->e_lfanew) + sizeof(IMAGE_NT_HEADERS32) > size) {
            return false;
        }

        const IMAGE_NT_HEADERS* ntHeaders = reinterpret_cast<const IMAGE_NT_HEADERS*>(data + dosHeader->e_lfanew);
        if (ntHeaders->Signature != IMAGE_NT_SIGNATURE) return false;

        return true;
    }

    bool PeParser::CheckHardVetoMarkers(const uint8_t* data, size_t size, std::string& outMarker) {
        if (!data || size == 0) return false;

        auto searchSubstr = [data, size](const std::string& pattern) -> bool {
            if (pattern.empty() || size < pattern.size()) return false;
            auto it = std::search(data, data + size, pattern.begin(), pattern.end());
            return (it != data + size);
        };

        // 1. Майнеры (расшифровка на стеке)
        {
            std::string stratumTcp = HardVetoMarkers::STRATUM_TCP.Decrypt();
            if (searchSubstr(stratumTcp)) { outMarker = "Miner: stratum+tcp"; return true; }

            std::string stratumSsl = HardVetoMarkers::STRATUM_SSL.Decrypt();
            if (searchSubstr(stratumSsl)) { outMarker = "Miner: stratum+ssl"; return true; }

            std::string xmrig = HardVetoMarkers::XMRIG.Decrypt();
            if (searchSubstr(xmrig)) { outMarker = "Miner: xmrig"; return true; }

            std::string cryptonight = HardVetoMarkers::CRYPTONIGHT.Decrypt();
            if (searchSubstr(cryptonight)) { outMarker = "Miner: cryptonight"; return true; }
        }

        // 2. Эксфильтрация данных (расшифровка на стеке)
        {
            std::string discordHook = HardVetoMarkers::DISCORD_WEBHOOK.Decrypt();
            if (searchSubstr(discordHook)) { outMarker = "Exfiltration: Discord Webhook"; return true; }

            std::string tgBot = HardVetoMarkers::TELEGRAM_BOT.Decrypt();
            if (searchSubstr(tgBot)) { outMarker = "Exfiltration: Telegram Bot API"; return true; }
        }

        // 3. Прямые инъекции: комбинация VirtualAllocEx + WriteProcessMemory + CreateRemoteThread
        {
            std::string vaEx = HardVetoMarkers::VIRTUAL_ALLOC_EX.Decrypt();
            std::string wpm = HardVetoMarkers::WRITE_PROCESS_MEMORY.Decrypt();
            std::string crt = HardVetoMarkers::CREATE_REMOTE_THREAD.Decrypt();

            if (searchSubstr(vaEx) && searchSubstr(wpm) && searchSubstr(crt)) {
                outMarker = "Code Injection: VirtualAllocEx + WriteProcessMemory + CreateRemoteThread";
                return true;
            }
        }

        return false;
    }

    bool PeParser::IsNameWhitelisted(const std::wstring& filePath, const std::vector<std::wstring>& whitelist) {
        fs::path p(filePath);
        std::wstring filename = p.filename().wstring();
        std::transform(filename.begin(), filename.end(), filename.begin(), ::towlower);

        for (const auto& item : whitelist) {
            std::wstring token = item;
            std::transform(token.begin(), token.end(), token.begin(), ::towlower);
            if (!token.empty() && filename.find(token) != std::wstring::npos) {
                return true;
            }
        }
        return false;
    }

    PeScanResult PeParser::AnalyzeFile(const std::wstring& filePath, const std::vector<std::wstring>& whitelist) {
        PeScanResult res;

        // Открываем файл с защитой
        HANDLE hFile = FileGuard::OpenSafeFile(
            filePath,
            GENERIC_READ,
            FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
            OPEN_EXISTING
        );

        if (hFile == INVALID_HANDLE_VALUE) {
            res.detectedReason = "Could not open file";
            return res;
        }

        FileValidationResult val = FileGuard::ValidateFileHandle(hFile, filePath);
        if (!val.isValid) {
            CloseHandle(hFile);
            res.detectedReason = "Invalid file link or reparse point";
            return res;
        }

        LARGE_INTEGER fSize;
        if (!GetFileSizeEx(hFile, &fSize) || fSize.QuadPart <= 0 || fSize.QuadPart > 100 * 1024 * 1024) {
            // Ограничение размера 100 МБ для оперативного анализа
            CloseHandle(hFile);
            return res;
        }

        std::vector<uint8_t> buffer(static_cast<size_t>(fSize.QuadPart));
        DWORD bytesRead = 0;
        if (!ReadFile(hFile, buffer.data(), static_cast<DWORD>(buffer.size()), &bytesRead, NULL) || bytesRead != buffer.size()) {
            CloseHandle(hFile);
            return res;
        }
        CloseHandle(hFile);

        res.sha256 = ComputeSha256(buffer);
        res.isPeFile = ValidatePeStructure(buffer.data(), buffer.size());

        // 1. ПРАВИЛО HARD VETO (Мгновенная изоляция):
        // Поиск обфусцированных маркеров. Имя файла НЕ снижает скоринг!
        std::string marker;
        if (CheckHardVetoMarkers(buffer.data(), buffer.size(), marker)) {
            res.verdict = ScanVerdict::MalwareHardVeto;
            res.detectedReason = marker;
            return res;
        }

        // 2. Если Hard Veto не сработал, проверяем белый список утилит (unlocker, bypass, activator)
        if (IsNameWhitelisted(filePath, whitelist)) {
            res.verdict = ScanVerdict::BypassAllowed;
            return res;
        }

        // 3. Файл не имеет явных hard veto маркеров
        res.verdict = ScanVerdict::Suspicious;
        return res;
    }

}
