#include "common.hpp"
#include "obfuscation.hpp"
#include "security/installer.hpp"
#include "security/file_guard.hpp"
#include "security/quarantine.hpp"
#include "engine/timer_res.hpp"
#include "engine/power_manager.hpp"
#include "engine/network_optimizer.hpp"
#include "engine/standby_list.hpp"
#include "engine/process_optimizer.hpp"
#include "scanner/directory_watcher.hpp"
#include "toast/toast_notification.hpp"
#include "config/config_manager.hpp"
#include "graphics/window.hpp"
#include "graphics/game_sense.hpp"

using namespace KristMr;

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE, LPWSTR lpCmdLine, int nCmdShow) {
    // 1. Настройка высокого DPI (Per-Monitor v2)
    SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);

    // 2. Инициализация самозащиты (кэширование PID и собственного пути для исключения из сканирования)
    SelfProtection::Initialize();

    // 3. Инициализация COM
    HRESULT hrCom = CoInitializeEx(NULL, COINIT_MULTITHREADED);

    // 4. Проверка аргумента установки
    std::wstring cmdLine = lpCmdLine ? lpCmdLine : L"";
    if (cmdLine.find(L"--install") != std::wstring::npos) {
        Installer::PerformInstallation();
        if (SUCCEEDED(hrCom)) CoUninitialize();
        return 0;
    }

    // 5. Проверка развертывания и первичная регистрация
    if (!Installer::IsInstalled() && !Installer::IsRunningFromProgramFiles()) {
        if (Installer::IsProcessElevated()) {
            Installer::PerformInstallation();
        }
    }

    // 6. Проверка мьютекса единственного экземпляра
    HANDLE hMutex = CreateMutexW(NULL, TRUE, APP_MUTEX_NAME);
    if (GetLastError() == ERROR_ALREADY_EXISTS) {
        if (hMutex) CloseHandle(hMutex);
        if (SUCCEEDED(hrCom)) CoUninitialize();
        return 0;
    }

    // 7. Инициализация конфигураций (%ProgramData%\KristMr\config\)
    ConfigManager::Initialize();
    const auto& settings = ConfigManager::GetSettings();

    // 8. Инициализация подсистем безопасности
    QuarantineManager::Initialize();
    ReputationScanner::Initialize(settings.virustotal_api_key);
    ToastNotification::Initialize();

    // 9. Оптимизация системного ядра (Гипер-режим)
    PowerManager::CheckAndRecoverCrashedScheme();

    if (settings.timer_resolution_05ms) {
        TimerResolutionManager::EnableHighResolutionTimer();
    }

    if (settings.hyper_mode) {
        PowerManager::EnableHyperPowerProfile();
        NetworkOptimizer::ApplyNetworkTweaks();
    }

    if (settings.flush_dns) {
        NetworkOptimizer::FlushDnsCache();
    }

    if (settings.single_purge_standby) {
        StandbyListManager::PurgeStandbyListOnce();
    }

    if (settings.clean_temp_junk) {
        FileGuard::CleanTempJunkSafe();
    }

    ProcessOptimizer::Initialize(ConfigManager::GetBlacklist());

    if (settings.game_focus) {
        GameSense::Start();
    }

    // 10. Создание и отображение окна
    MainWindow mainWindow;
    if (!mainWindow.Create(hInstance)) {
        if (hMutex) { ReleaseMutex(hMutex); CloseHandle(hMutex); }
        if (SUCCEEDED(hrCom)) CoUninitialize();
        return 1;
    }
    mainWindow.Show();

    // 11. Запуск антивирусного монитора (IOCP Watcher)
    DirectoryWatcher dirWatcher;
    if (settings.realtime_antivirus) {
        dirWatcher.Start(
            ConfigManager::GetWhitelist(),
            [&mainWindow](CrystalState state, const std::wstring& filePath, const std::string& reason) {
                mainWindow.GetRenderer().SetTargetColorState(state);

                fs::path p(filePath);
                std::wstring fileName = p.filename().wstring();

                if (state == CrystalState::ThreatDetected) {
                    ToastNotification::ShowToast(
                        L"KristMr: Вредоносная угроза нейтрализована!",
                        L"Файл " + fileName + L" изолирован в карантине (Hard Veto)",
                        mainWindow.GetHwnd()
                    );
                } else if (state == CrystalState::QuarantineAlert) {
                    ToastNotification::ShowToast(
                        L"KristMr: Изоляция подозрительного файла",
                        L"Файл " + fileName + L" изолирован с неподтвержденной репутацией (.locked)",
                        mainWindow.GetHwnd()
                    );
                }
            }
        );
    }

    // Таймер для периодической оптимизации процессов и Game Focus
    SetTimer(mainWindow.GetHwnd(), 1, 1000, NULL);

    // 12. Основной цикл сообщений Win32
    MSG msg = {};
    while (GetMessageW(&msg, NULL, 0, 0)) {
        if (msg.message == WM_TIMER && msg.wParam == 1) {
            if (settings.hyper_mode) {
                ProcessOptimizer::OptimizeBlacklistProcesses();
            }
            if (settings.game_focus) {
                ProcessOptimizer::UpdateGameFocus();
            }
            continue;
        }

        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    // 13. ПОРЯДОК ШТАТНОГО ВЫХОДА И ДЕИНИЦИАЛИЗАЦИИ (Раздел 6 манифеста)
    KillTimer(mainWindow.GetHwnd(), 1);

    // Шаг 1: Остановка рендеринга и IOCP пула
    dirWatcher.Stop();
    GameSense::Stop();
    mainWindow.GetRenderer().Shutdown();

    // Шаг 2-4: Восстановление схемы электропитания и удаление временных файлов
    PowerManager::RestoreOriginalPowerScheme();

    // Шаг 5: Восстановление реестра и удаление registry_backup.bin
    NetworkOptimizer::RestoreRegistryTweaks();

    // Шаг 6: Сброс системного таймера
    TimerResolutionManager::RestoreTimerResolution();

    // Шаг 7: Возврат стандартных приоритетов процессов
    ProcessOptimizer::RestoreProcessPriorities();

    // Освобождение мьютекса
    if (hMutex) {
        ReleaseMutex(hMutex);
        CloseHandle(hMutex);
    }

    if (SUCCEEDED(hrCom)) {
        CoUninitialize();
    }

    return 0;
}
