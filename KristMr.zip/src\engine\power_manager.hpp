#pragma once
#include "../common.hpp"

namespace KristMr {

    enum class CpuTopologyType {
        Monolithic,       // Однородный монолитный CPU (отключаем парковку: 100%)
        IntelHybrid,      // Гетерогенный CPU (P+E ядра - сохраняем балансировку)
        AmdAsymmetricL3   // Асимметричный L3 (3D V-Cache - сохраняем балансировку)
    };

    class PowerManager {
    public:
        // Проверка предыдущего аварийного завершения и восстановление схемы
        static void CheckAndRecoverCrashedScheme();

        // Активация гипер-профиля питания
        static bool EnableHyperPowerProfile();

        // Восстановление оригинальной схемы питания и удаление last_power_scheme.bin
        static void RestoreOriginalPowerScheme();

        // Определение топологии процессора
        static CpuTopologyType DetectCpuTopology();

    private:
        static std::wstring GetPowerBackupFilePath();
        static bool SaveGuidToFile(const GUID& guid, const std::wstring& path);
        static bool LoadGuidFromFile(GUID& guid, const std::wstring& path);

        inline static GUID s_originalSchemeGuid = {};
        inline static bool s_hasOriginalScheme = false;
        inline static GUID s_hyperSchemeGuid = {};
    };

}
