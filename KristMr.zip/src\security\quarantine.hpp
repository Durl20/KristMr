#pragma once
#include "../common.hpp"

namespace KristMr {

    struct QuarantineResult {
        bool success = false;
        std::wstring quarantinePath = L"";
        std::wstring errorReason = L"";
    };

    class QuarantineManager {
    public:
        // Инициализация директорий карантина
        static void Initialize();

        // Изоляция файла в карантин
        static QuarantineResult IsolateFile(const std::wstring& targetPath);

        // Получение основного пути карантина на C:
        static std::wstring GetMainQuarantineDir();

    private:
        // Применение NTFS Privilege Trap
        static bool ApplyNtfsPrivilegeTrap(const std::wstring& path);

        // Получение корня диска
        static std::wstring GetVolumeRoot(const std::wstring& path);
    };

}
