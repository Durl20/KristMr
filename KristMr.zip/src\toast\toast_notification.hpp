#pragma once
#include "../common.hpp"

namespace KristMr {

    class ToastNotification {
    public:
        static void Initialize();

        // Показ нативного уведомления
        static void ShowToast(const std::wstring& title, const std::wstring& message, HWND hWndFallback = NULL);
    };

}
