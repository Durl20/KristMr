#pragma once
#include "../common.hpp"
#include "d3d_renderer.hpp"

namespace KristMr {

    class MainWindow {
    public:
        MainWindow();
        ~MainWindow();

        bool Create(HINSTANCE hInstance);
        void Show();
        void HideToTray();
        void RestoreFromTray();

        HWND GetHwnd() const { return m_hWnd; }
        D3DRenderer& GetRenderer() { return m_renderer; }

        static LRESULT CALLBACK WndProcStatic(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

    private:
        LRESULT WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

        void AddTrayIcon();
        void RemoveTrayIcon();
        void ShowTrayContextMenu(int x, int y);

        HWND m_hWnd = NULL;
        HINSTANCE m_hInstance = NULL;
        D3DRenderer m_renderer;
        NOTIFYICONDATAW m_nid = {};
        bool m_inTray = false;

        int m_currentWidth = 420;
        int m_currentHeight = 600;
    };

}
