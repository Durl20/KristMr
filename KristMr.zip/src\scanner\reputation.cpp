#include "reputation.hpp"

namespace KristMr {

    void ReputationScanner::Initialize(const std::string& vtApiKey) {
        s_vtApiKey = vtApiKey;
    }

    bool ReputationScanner::CheckLruCache(const std::string& sha256, ReputationStatus& outStatus) {
        std::lock_guard<std::mutex> lock(s_cacheMutex);
        auto it = s_lruMap.find(sha256);
        if (it != s_lruMap.end()) {
            outStatus = it->second->second;
            // Перемещаем в начало списка (Most Recently Used)
            s_lruList.splice(s_lruList.begin(), s_lruList, it->second);
            return true;
        }
        return false;
    }

    void ReputationScanner::UpdateLruCache(const std::string& sha256, ReputationStatus status) {
        std::lock_guard<std::mutex> lock(s_cacheMutex);
        auto it = s_lruMap.find(sha256);
        if (it != s_lruMap.end()) {
            it->second->second = status;
            s_lruList.splice(s_lruList.begin(), s_lruList, it->second);
            return;
        }

        if (s_lruList.size() >= LRU_CAPACITY) {
            auto oldest = s_lruList.end();
            --oldest;
            s_lruMap.erase(oldest->first);
            s_lruList.pop_back();
        }

        s_lruList.push_front({ sha256, status });
        s_lruMap[sha256] = s_lruList.begin();
    }

    std::string ReputationScanner::HttpPost(const std::wstring& host, const std::wstring& path, const std::string& postData, const std::wstring& headers) {
        std::string response = "";
        HINTERNET hSession = WinHttpOpen(L"KristMr-Monitor/2.1", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
        if (!hSession) return response;

        // Таймауты 5 секунд
        WinHttpSetTimeouts(hSession, 5000, 5000, 5000, 5000);

        HINTERNET hConnect = WinHttpConnect(hSession, host.c_str(), INTERNET_DEFAULT_HTTPS_PORT, 0);
        if (hConnect) {
            HINTERNET hRequest = WinHttpOpenRequest(hConnect, L"POST", path.c_str(), NULL, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE);
            if (hRequest) {
                BOOL bSend = WinHttpSendRequest(
                    hRequest,
                    headers.empty() ? WINHTTP_NO_ADDITIONAL_HEADERS : headers.c_str(),
                    static_cast<DWORD>(headers.length()),
                    (LPVOID)postData.data(),
                    static_cast<DWORD>(postData.size()),
                    static_cast<DWORD>(postData.size()),
                    0
                );

                if (bSend && WinHttpReceiveResponse(hRequest, NULL)) {
                    DWORD bytesAvail = 0;
                    while (WinHttpQueryDataAvailable(hRequest, &bytesAvail) && bytesAvail > 0) {
                        std::vector<char> buf(bytesAvail + 1, 0);
                        DWORD bytesRead = 0;
                        if (WinHttpReadData(hRequest, buf.data(), bytesAvail, &bytesRead)) {
                            response.append(buf.data(), bytesRead);
                        }
                    }
                }
                WinHttpCloseHandle(hRequest);
            }
            WinHttpCloseHandle(hConnect);
        }
        WinHttpCloseHandle(hSession);
        return response;
    }

    std::string ReputationScanner::HttpGet(const std::wstring& host, const std::wstring& path, const std::wstring& headers) {
        std::string response = "";
        HINTERNET hSession = WinHttpOpen(L"KristMr-Monitor/2.1", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
        if (!hSession) return response;

        WinHttpSetTimeouts(hSession, 5000, 5000, 5000, 5000);

        HINTERNET hConnect = WinHttpConnect(hSession, host.c_str(), INTERNET_DEFAULT_HTTPS_PORT, 0);
        if (hConnect) {
            HINTERNET hRequest = WinHttpOpenRequest(hConnect, L"GET", path.c_str(), NULL, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE);
            if (hRequest) {
                BOOL bSend = WinHttpSendRequest(
                    hRequest,
                    headers.empty() ? WINHTTP_NO_ADDITIONAL_HEADERS : headers.c_str(),
                    static_cast<DWORD>(headers.length()),
                    WINHTTP_NO_REQUEST_DATA,
                    0,
                    0,
                    0
                );

                if (bSend && WinHttpReceiveResponse(hRequest, NULL)) {
                    DWORD bytesAvail = 0;
                    while (WinHttpQueryDataAvailable(hRequest, &bytesAvail) && bytesAvail > 0) {
                        std::vector<char> buf(bytesAvail + 1, 0);
                        DWORD bytesRead = 0;
                        if (WinHttpReadData(hRequest, buf.data(), bytesAvail, &bytesRead)) {
                            response.append(buf.data(), bytesRead);
                        }
                    }
                }
                WinHttpCloseHandle(hRequest);
            }
            WinHttpCloseHandle(hConnect);
        }
        WinHttpCloseHandle(hSession);
        return response;
    }

    ReputationStatus ReputationScanner::QueryMalwareBazaar(const std::string& sha256) {
        std::string postData = "query=get_info&hash=" + sha256;
        std::wstring headers = L"Content-Type: application/x-www-form-urlencoded\r\n";
        std::string res = HttpPost(L"mb-api.abuse.ch", L"/api/v1/", postData, headers);

        if (res.empty()) {
            return ReputationStatus::Offline;
        }

        if (res.find("\"query_status\": \"ok\"") != std::string::npos) {
            return ReputationStatus::Malicious;
        }

        if (res.find("\"query_status\": \"hash_not_found\"") != std::string::npos) {
            return ReputationStatus::Unknown;
        }

        return ReputationStatus::Unknown;
    }

    ReputationStatus ReputationScanner::QueryVirusTotal(const std::string& sha256) {
        if (s_vtApiKey.empty()) {
            return ReputationStatus::Unknown; // Ключ отсутствует, VT запросы блокируются
        }

        // Строгий ограничитель частоты (1 запрос в 15 секунд, не более 500 в сутки)
        {
            std::lock_guard<std::mutex> lock(s_vtRateMutex);
            auto nowSys = std::chrono::system_clock::now();
            if (nowSys - s_vtDailyResetTime >= std::chrono::hours(24)) {
                s_vtDailyCount = 0;
                s_vtDailyResetTime = nowSys;
            }

            if (s_vtDailyCount >= 500) {
                return ReputationStatus::Unknown; // Лимит исчерпан
            }

            auto now = std::chrono::steady_clock::now();
            auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - s_lastVtRequestTime).count();
            if (elapsed < 15) {
                // Ждем недостающее время до 15 секунд
                std::this_thread::sleep_for(std::chrono::seconds(15 - elapsed));
            }
            s_lastVtRequestTime = std::chrono::steady_clock::now();
            s_vtDailyCount++;
        }

        std::wstring path = L"/api/v3/files/" + std::wstring(sha256.begin(), sha256.end());
        std::wstring headers = L"x-apikey: " + std::wstring(s_vtApiKey.begin(), s_vtApiKey.end()) + L"\r\n";

        std::string res = HttpGet(L"www.virustotal.com", path, headers);
        if (res.empty()) {
            return ReputationStatus::Offline;
        }

        // Парсинг наличия детектов malicious
        auto pos = res.find("\"malicious\":");
        if (pos != std::string::npos) {
            int malCount = 0;
            if (sscanf_s(res.c_str() + pos + 12, "%d", &malCount) == 1) {
                if (malCount >= 3) {
                    return ReputationStatus::Malicious;
                } else if (malCount == 0) {
                    return ReputationStatus::Safe;
                }
            }
        }

        return ReputationStatus::Unknown;
    }

    ReputationStatus ReputationScanner::QueryHashReputation(const std::string& sha256) {
        if (sha256.empty()) return ReputationStatus::Unknown;

        // 1. Проверяем локальный кэш
        ReputationStatus cached = ReputationStatus::Unknown;
        if (CheckLruCache(sha256, cached)) {
            return cached;
        }

        // 2. Проверяем MalwareBazaar
        ReputationStatus mbStatus = QueryMalwareBazaar(sha256);
        if (mbStatus == ReputationStatus::Malicious) {
            UpdateLruCache(sha256, mbStatus);
            return mbStatus;
        }

        // 3. Проверяем VirusTotal если есть ключ
        if (!s_vtApiKey.empty()) {
            ReputationStatus vtStatus = QueryVirusTotal(sha256);
            if (vtStatus != ReputationStatus::Unknown && vtStatus != ReputationStatus::Offline) {
                UpdateLruCache(sha256, vtStatus);
                return vtStatus;
            }
        }

        // Если оффлайн
        if (mbStatus == ReputationStatus::Offline) {
            return ReputationStatus::Offline;
        }

        UpdateLruCache(sha256, ReputationStatus::Unknown);
        return ReputationStatus::Unknown;
    }

}
