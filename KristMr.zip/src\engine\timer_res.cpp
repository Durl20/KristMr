#include "timer_res.hpp"

#ifndef PROCESS_POWER_THROTTLING_CURRENT_VERSION
#define PROCESS_POWER_THROTTLING_CURRENT_VERSION 1
#endif
#ifndef PROCESS_POWER_THROTTLING_IGNORE_TIMER_RESOLUTION
#define PROCESS_POWER_THROTTLING_IGNORE_TIMER_RESOLUTION 4
#endif

typedef struct _PROCESS_POWER_THROTTLING_STATE_LOCAL {
    ULONG Version;
    ULONG ControlMask;
    ULONG StateMask;
} PROCESS_POWER_THROTTLING_STATE_LOCAL;

namespace KristMr {

    bool TimerResolutionManager::EnableHighResolutionTimer() {
        if (s_isActive) return true;

        // 1. Обход EcoQoS для соблюдения разрешения таймера
        PROCESS_POWER_THROTTLING_STATE_LOCAL powerThrottling = {};
        powerThrottling.Version = PROCESS_POWER_THROTTLING_CURRENT_VERSION;
        powerThrottling.ControlMask = PROCESS_POWER_THROTTLING_IGNORE_TIMER_RESOLUTION;
        powerThrottling.StateMask = 0; // Игнорировать троттлинг таймера

        SetProcessInformation(
            GetCurrentProcess(),
            ProcessPowerThrottling,
            &powerThrottling,
            sizeof(powerThrottling)
        );

        // 2. Динамический вызов ntdll!NtSetTimerResolution
        HMODULE hNtDll = GetModuleHandleW(L"ntdll.dll");
        if (!hNtDll) {
            hNtDll = LoadLibraryW(L"ntdll.dll");
        }

        if (hNtDll) {
            s_pfnNtSetTimerResolution = reinterpret_cast<pfnNtSetTimerResolution>(
                GetProcAddress(hNtDll, "NtSetTimerResolution")
            );

            if (s_pfnNtSetTimerResolution) {
                // 5000 единиц по 100 нс = 500 мкс = 0.5 мс
                NTSTATUS status = s_pfnNtSetTimerResolution(5000, TRUE, &s_currentRes);
                if (status == STATUS_SUCCESS) {
                    s_isActive = true;
                    return true;
                }
            }
        }

        // Запасной вариант через timeBeginPeriod
        if (timeBeginPeriod(1) == TIMERR_NOERROR) {
            s_isActive = true;
            return true;
        }

        return false;
    }

    void TimerResolutionManager::RestoreTimerResolution() {
        if (!s_isActive) return;

        if (s_pfnNtSetTimerResolution) {
            s_pfnNtSetTimerResolution(5000, FALSE, &s_currentRes);
        } else {
            timeEndPeriod(1);
        }

        s_isActive = false;
    }

}
