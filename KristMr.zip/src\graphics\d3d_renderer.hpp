#pragma once
#include "../common.hpp"
#include "octahedron_mesh.hpp"
#include "game_sense.hpp"

namespace KristMr {

    struct alignas(16) ConstantBufferData {
        float currentColor[4];
        float time;
        float globalAlpha;
        float feather;
        float padding;
    };

    class D3DRenderer {
    public:
        D3DRenderer();
        ~D3DRenderer();

        bool Initialize(HWND hWnd, int width, int height);
        void Shutdown();

        void StartRenderThread();
        void StopRenderThread();

        void SetTargetColorState(CrystalState state);
        void SetMinimizedToTray(bool minimized);
        void ResizeBuffers(int newWidth, int newHeight);
        
        void AdjustGlobalAlpha(float delta);
        float GetGlobalAlpha() const { return m_globalAlpha.load(); }

    private:
        bool CreateD3DResources();
        void ReleaseD3DResources();
        void RenderLoop();
        void RenderFrame(float dt);
        void UpdateColorTransitions(float dt);

        HWND m_hWnd = NULL;
        int m_width = 420;
        int m_height = 600;

        ComPtr<ID3D11Device> m_device;
        ComPtr<ID3D11DeviceContext> m_context;
        ComPtr<IDXGISwapChain> m_swapChain;
        ComPtr<ID3D11RenderTargetView> m_renderTargetView;
        ComPtr<ID3D11VertexShader> m_vertexShader;
        ComPtr<ID3D11PixelShader> m_pixelShader;
        ComPtr<ID3D11InputLayout> m_inputLayout;
        ComPtr<ID3D11Buffer> m_vertexBuffer;
        ComPtr<ID3D11Buffer> m_constantBuffer;
        ComPtr<ID3D11BlendState> m_blendState;
        ComPtr<ID3D11RasterizerState> m_rasterizerState;
        ComPtr<ID3D11DepthStencilState> m_depthStencilState;

        // Поток рендеринга
        std::thread m_renderThread;
        std::atomic<bool> m_running{ false };
        std::atomic<bool> m_minimizedToTray{ false };
        std::atomic<bool> m_needsResize{ false };
        int m_pendingWidth = 0;
        int m_pendingHeight = 0;
        std::mutex m_resourceMutex;

        // Цвета и физика переходов
        ColorRGBA m_currentColor = COLOR_AZURE;
        ColorRGBA m_targetColor = COLOR_AZURE;
        std::atomic<CrystalState> m_crystalState{ CrystalState::HyperActive };
        std::atomic<float> m_globalAlpha{ 1.0f };

        float m_attackTimer = 0.0f;
        float m_totalTime = 0.0f;
        float m_rotY = 0.0f;

        OctahedronModel m_model;
    };

}
