#include "directory_watcher.hpp"
#include "../obfuscation.hpp"
#include "../security/file_guard.hpp"

namespace KristMr {

    DirectoryWatcher::DirectoryWatcher() {}

    DirectoryWatcher::~DirectoryWatcher() {
        Stop();
    }

    bool DirectoryWatcher::WaitForFileWriteComplete(const std::wstring& filePath) {
        // Ожидание завершения записи (цикл до 20 итераций с шагом 80 мс)
        // с открытием файла через FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE
        for (int i = 0; i < 20; ++i) {
            HANDLE hFile = CreateFileW(
                filePath.c_str(),
                GENERIC_READ,
                FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                NULL,
                OPEN_EXISTING,
                FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OPEN_REPARSE_POINT,
                NULL
            );

            if (hFile != INVALID_HANDLE_VALUE) {
                LARGE_INTEGER size1 = {}, size2 = {};
                GetFileSizeEx(hFile, &size1);
                CloseHandle(hFile);

                std::this_thread::sleep_for(std::chrono::milliseconds(80));

                hFile = CreateFileW(
                    filePath.c_str(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                    NULL,
                    OPEN_EXISTING,
                    FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OPEN_REPARSE_POINT,
                    NULL
                );

                if (hFile != INVALID_HANDLE_VALUE) {
                    GetFileSizeEx(hFile, &size2);
                    CloseHandle(hFile);

                    // Если размер стабилен и больше нуля, запись завершена
                    if (size1.QuadPart == size2.QuadPart && size2.QuadPart > 0) {
                        return true;
                    }
                }
            } else {
                std::this_thread::sleep_for(std::chrono::milliseconds(80));
            }
        }
        return false;
    }

    void DirectoryWatcher::ProcessFile(const std::wstring& filePath) {
        if (SelfProtection::IsSelfFile(filePath)) return;

        fs::path p(filePath);
        std::wstring ext = p.extension().wstring();
        std::transform(ext.begin(), ext.end(), ext.begin(), ::towlower);

        // Игнорируем временные и уже заблокированные файлы
        if (ext == L".locked" || ext == L".tmp" || ext == L".crdownload" || ext == L".part") {
            return;
        }

        // Ждем завершения сброса буферов на диск
        if (!WaitForFileWriteComplete(filePath)) {
            return;
        }

        // Анализируем PE-структуру и эвристику
        PeScanResult scan = PeParser::AnalyzeFile(filePath, m_whitelist);

        if (scan.verdict == ScanVerdict::MalwareHardVeto) {
            // Мгновенная изоляция (Hard Veto)
            QuarantineResult qRes = QuarantineManager::IsolateFile(filePath);
            if (m_stateCallback) {
                m_stateCallback(CrystalState::ThreatDetected, filePath, scan.detectedReason);
            }
            return;
        }

        if (scan.verdict == ScanVerdict::BypassAllowed) {
            // Безопасный unlocker/bypass/patcher
            if (m_stateCallback) {
                m_stateCallback(CrystalState::BypassAllowed, filePath, "Whitelisted safe utility");
            }
            return;
        }

        if (scan.isPeFile) {
            // Проверяем онлайн-репутацию по хэшу
            ReputationStatus rep = ReputationScanner::QueryHashReputation(scan.sha256);

            if (rep == ReputationStatus::Malicious) {
                QuarantineManager::IsolateFile(filePath);
                if (m_stateCallback) {
                    m_stateCallback(CrystalState::ThreatDetected, filePath, "Malicious reputation confirmed");
                }
            } else if (rep == ReputationStatus::Safe) {
                if (m_stateCallback) {
                    m_stateCallback(CrystalState::BypassAllowed, filePath, "Verified safe file");
                }
            } else {
                // Сценарий «Хеш неизвестен / Сеть недоступна»:
                // Файл отправляется в карантин (.locked), кристалл мигает янтарным
                QuarantineManager::IsolateFile(filePath);
                if (m_stateCallback) {
                    m_stateCallback(CrystalState::QuarantineAlert, filePath, "Unknown reputation / Offline isolation");
                }
            }
        }
    }

    void DirectoryWatcher::PerformDifferentialScan(const std::wstring& dirPath) {
        try {
            for (const auto& entry : fs::directory_iterator(dirPath, fs::directory_options::skip_permission_denied)) {
                std::error_code ec;
                if (entry.is_regular_file(ec)) {
                    ProcessFile(entry.path().wstring());
                }
            }
        } catch (...) {}
    }

    void DirectoryWatcher::RegisterWatchDirectory(const std::wstring& path) {
        if (GetFileAttributesW(path.c_str()) == INVALID_FILE_ATTRIBUTES) {
            CreateDirectoryW(path.c_str(), NULL);
        }

        HANDLE hDir = CreateFileW(
            path.c_str(),
            FILE_LIST_DIRECTORY,
            FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
            NULL,
            OPEN_EXISTING,
            FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OVERLAPPED,
            NULL
        );

        if (hDir == INVALID_HANDLE_VALUE) return;

        auto ctx = std::make_unique<WatcherContext>();
        ctx->hDir = hDir;
        ctx->dirPath = path;
        ctx->buffer.resize(64 * 1024); // Буфер 64 КБ

        // Привязываем к IOCP
        if (CreateIoCompletionPort(hDir, m_hIocp, reinterpret_cast<ULONG_PTR>(ctx.get()), 0) == NULL) {
            CloseHandle(hDir);
            return;
        }

        DWORD bytesReturned = 0;
        BOOL ok = ReadDirectoryChangesW(
            ctx->hDir,
            ctx->buffer.data(),
            static_cast<DWORD>(ctx->buffer.size()),
            TRUE, // рекурсивно
            FILE_NOTIFY_CHANGE_FILE_NAME | FILE_NOTIFY_CHANGE_LAST_WRITE | FILE_NOTIFY_CHANGE_SIZE,
            &bytesReturned,
            &ctx->overlapped,
            NULL
        );

        if (ok || GetLastError() == ERROR_IO_PENDING) {
            m_contexts.push_back(std::move(ctx));
        } else {
            CloseHandle(hDir);
        }
    }

    void DirectoryWatcher::WorkerThread() {
        while (m_running) {
            DWORD bytesTransferred = 0;
            ULONG_PTR completionKey = 0;
            LPOVERLAPPED pOverlapped = NULL;

            BOOL ok = GetQueuedCompletionStatus(
                m_hIocp,
                &bytesTransferred,
                &completionKey,
                &pOverlapped,
                1000 // 1 секунда таймаут для проверки флага m_running
            );

            if (!m_running) break;

            if (!ok) {
                DWORD err = GetLastError();
                if (err == WAIT_TIMEOUT) continue;

                if (err == ERROR_NOTIFY_ENUM_DIR && completionKey) {
                    // Переполнение буфера: фоновая дифференциальная сверка
                    WatcherContext* ctx = reinterpret_cast<WatcherContext*>(completionKey);
                    PerformDifferentialScan(ctx->dirPath);

                    // Перезапуск ReadDirectoryChangesW
                    DWORD bytesRet = 0;
                    ReadDirectoryChangesW(
                        ctx->hDir,
                        ctx->buffer.data(),
                        static_cast<DWORD>(ctx->buffer.size()),
                        TRUE,
                        FILE_NOTIFY_CHANGE_FILE_NAME | FILE_NOTIFY_CHANGE_LAST_WRITE | FILE_NOTIFY_CHANGE_SIZE,
                        &bytesRet,
                        &ctx->overlapped,
                        NULL
                    );
                }
                continue;
            }

            if (completionKey && pOverlapped) {
                WatcherContext* ctx = reinterpret_cast<WatcherContext*>(completionKey);

                if (bytesTransferred > 0) {
                    uint8_t* base = ctx->buffer.data();
                    DWORD offset = 0;

                    do {
                        FILE_NOTIFY_INFORMATION* fni = reinterpret_cast<FILE_NOTIFY_INFORMATION*>(base + offset);
                        std::wstring relName(fni->FileName, fni->FileNameLength / sizeof(wchar_t));
                        std::wstring fullPath = ctx->dirPath + L"\\" + relName;

                        if (fni->Action == FILE_ACTION_ADDED ||
                            fni->Action == FILE_ACTION_MODIFIED ||
                            fni->Action == FILE_ACTION_RENAMED_NEW_NAME) {
                            ProcessFile(fullPath);
                        }

                        if (fni->NextEntryOffset == 0) break;
                        offset += fni->NextEntryOffset;
                    } while (offset < bytesTransferred);
                }

                // Перезапуск слушателя
                DWORD bytesRet = 0;
                memset(&ctx->overlapped, 0, sizeof(OVERLAPPED));
                ReadDirectoryChangesW(
                    ctx->hDir,
                    ctx->buffer.data(),
                    static_cast<DWORD>(ctx->buffer.size()),
                    TRUE,
                    FILE_NOTIFY_CHANGE_FILE_NAME | FILE_NOTIFY_CHANGE_LAST_WRITE | FILE_NOTIFY_CHANGE_SIZE,
                    &bytesRet,
                    &ctx->overlapped,
                    NULL
                );
            }
        }
    }

    bool DirectoryWatcher::Start(const std::vector<std::wstring>& whitelist, StateChangeCallback stateCallback) {
        if (m_running) return true;

        m_whitelist = whitelist;
        m_stateCallback = stateCallback;

        m_hIocp = CreateIoCompletionPort(INVALID_HANDLE_VALUE, NULL, 0, 0);
        if (!m_hIocp) return false;

        m_running = true;

        // Мониторинг системных каталогов:
        // 1. Downloads
        wchar_t downloadsPath[MAX_PATH];
        if (SUCCEEDED(SHGetFolderPathW(NULL, CSIDL_PROFILE, NULL, 0, downloadsPath))) {
            RegisterWatchDirectory(std::wstring(downloadsPath) + L"\\Downloads");
            RegisterWatchDirectory(std::wstring(downloadsPath) + L"\\Desktop");
        }

        // 2. Temp
        wchar_t tempPath[MAX_PATH];
        if (GetTempPathW(MAX_PATH, tempPath) > 0) {
            std::wstring tempStr = tempPath;
            if (!tempStr.empty() && tempStr.back() == L'\\') {
                tempStr.pop_back();
            }
            RegisterWatchDirectory(tempStr);
        }

        m_workerThread = std::thread(&DirectoryWatcher::WorkerThread, this);
        return true;
    }

    void DirectoryWatcher::Stop() {
        if (!m_running) return;
        m_running = false;

        if (m_hIocp) {
            PostQueuedCompletionStatus(m_hIocp, 0, 0, NULL);
        }

        if (m_workerThread.joinable()) {
            m_workerThread.join();
        }

        for (auto& ctx : m_contexts) {
            if (ctx->hDir != INVALID_HANDLE_VALUE) {
                CloseHandle(ctx->hDir);
            }
        }
        m_contexts.clear();

        if (m_hIocp) {
            CloseHandle(m_hIocp);
            m_hIocp = NULL;
        }
    }

}
