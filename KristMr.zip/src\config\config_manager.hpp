#pragma once
#include "../common.hpp"

namespace KristMr {

    struct AppSettings {
        bool hyper_mode = true;
        bool game_focus = true;
        bool realtime_antivirus = true;
        bool smart_unlocker_pass = true;
        bool clean_temp_junk = true;
        bool flush_dns = true;
        bool timer_resolution_05ms = true;
        bool single_purge_standby = true;
        std::string virustotal_api_key = "";
    };

    class ConfigManager {
    public:
        static void Initialize();

        static const AppSettings& GetSettings() { return s_settings; }
        static const std::vector<std::wstring>& GetBlacklist() { return s_blacklist; }
        static const std::vector<std::wstring>& GetWhitelist() { return s_whitelist; }

        static std::wstring GetConfigDir();

    private:
        static void EnsureConfigFilesExist();
        static void LoadSettings();
        static void LoadBlacklist();
        static void LoadWhitelist();

        inline static AppSettings s_settings;
        inline static std::vector<std::wstring> s_blacklist;
        inline static std::vector<std::wstring> s_whitelist;
    };

}
