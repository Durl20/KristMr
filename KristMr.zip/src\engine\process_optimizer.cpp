#include "process_optimizer.hpp"
#include "../obfuscation.hpp"
#include <tlhelp32.h>

#ifndef PROCESS_POWER_THROTTLING_CURRENT_VERSION
#define PROCESS_POWER_THROTTLING_CURRENT_VERSION 1
#endif
#ifndef PROCESS_POWER_THROTTLING_EXECUTION_SPEED
#define PROCESS_POWER_THROTTLING_EXECUTION_SPEED 1
#endif

typedef struct _PROCESS_POWER_THROTTLING_STATE_LOCAL {
    ULONG Version;
    ULONG ControlMask;
    ULONG StateMask;
} PROCESS_POWER_THROTTLING_STATE_LOCAL;

namespace KristMr {

    void ProcessOptimizer::Initialize(const std::vector<std::wstring>& blacklist) {
        std::lock_guard<std::mutex> lock(s_mutex);
        s_blacklist.clear();

        for (const auto& item : blacklist) {
            std::wstring lower = item;
            std::transform(lower.begin(), lower.end(), lower.begin(), ::towlower);

            // Discord по умолчанию жестко исключен из блэклиста
            if (lower.find(L"discord") != std::wstring::npos) {
                continue;
            }
            s_blacklist.push_back(lower);
        }
    }

    void ProcessOptimizer::SetProcessIoPriorityVeryLow(HANDLE hProcess) {
        HMODULE hNtDll = GetModuleHandleW(L"ntdll.dll");
        if (!hNtDll) return;

        pfnNtSetInformationProcess pfnNtSetInfoProc = reinterpret_cast<pfnNtSetInformationProcess>(
            GetProcAddress(hNtDll, "NtSetInformationProcess")
        );
        if (pfnNtSetInfoProc) {
            ULONG ioPriority = 0; // 0 = Very Low
            // 33 = ProcessIoPriority
            pfnNtSetInfoProc(hProcess, 33, &ioPriority, sizeof(ULONG));
        }
    }

    void ProcessOptimizer::ApplyThrottlingToProcess(DWORD pid) {
        if (SelfProtection::IsSelfPid(pid)) return;

        HANDLE hProc = OpenProcess(PROCESS_SET_INFORMATION, FALSE, pid);
        if (!hProc) return;

        // 1. Понижение класса приоритета до IDLE
        SetPriorityClass(hProc, IDLE_PRIORITY_CLASS);

        // 2. I/O приоритет = Very Low
        SetProcessIoPriorityVeryLow(hProc);

        // 3. Активация EcoQoS
        PROCESS_POWER_THROTTLING_STATE_LOCAL throttling = {};
        throttling.Version = PROCESS_POWER_THROTTLING_CURRENT_VERSION;
        throttling.ControlMask = PROCESS_POWER_THROTTLING_EXECUTION_SPEED;
        throttling.StateMask = PROCESS_POWER_THROTTLING_EXECUTION_SPEED;

        SetProcessInformation(hProc, ProcessPowerThrottling, &throttling, sizeof(throttling));

        CloseHandle(hProc);
    }

    void ProcessOptimizer::OptimizeBlacklistProcesses() {
        HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (hSnapshot == INVALID_HANDLE_VALUE) return;

        PROCESSENTRY32W pe = {};
        pe.dwSize = sizeof(pe);

        if (Process32FirstW(hSnapshot, &pe)) {
            do {
                std::wstring exeName = pe.szExeFile;
                std::transform(exeName.begin(), exeName.end(), exeName.begin(), ::towlower);

                bool isBlacklisted = false;
                {
                    std::lock_guard<std::mutex> lock(s_mutex);
                    for (const auto& bl : s_blacklist) {
                        if (exeName == bl) {
                            isBlacklisted = true;
                            break;
                        }
                    }
                }

                if (isBlacklisted) {
                    ApplyThrottlingToProcess(pe.th32ProcessID);
                }
            } while (Process32NextW(hSnapshot, &pe));
        }

        CloseHandle(hSnapshot);
    }

    void ProcessOptimizer::UpdateGameFocus() {
        HWND hFg = GetForegroundWindow();
        if (!hFg) return;

        DWORD fgPid = 0;
        GetWindowThreadProcessId(hFg, &fgPid);
        if (fgPid == 0 || SelfProtection::IsSelfPid(fgPid)) return;

        std::lock_guard<std::mutex> lock(s_mutex);
        if (fgPid == s_lastBoostedPid) {
            return; // Процесс уже оптимизирован, избегаем повторных вызовов
        }

        // Возвращаем старому процессу нормальный приоритет
        if (s_lastBoostedPid != 0) {
            HANDLE hOld = OpenProcess(PROCESS_SET_INFORMATION, FALSE, s_lastBoostedPid);
            if (hOld) {
                SetPriorityClass(hOld, NORMAL_PRIORITY_CLASS);
                CloseHandle(hOld);
            }
        }

        // Повышаем приоритет новому активному процессу
        HANDLE hNew = OpenProcess(PROCESS_SET_INFORMATION, FALSE, fgPid);
        if (hNew) {
            if (SetPriorityClass(hNew, HIGH_PRIORITY_CLASS)) {
                s_lastBoostedPid = fgPid;
            }
            CloseHandle(hNew);
        } else {
            // Ошибки отказа в доступе (Vanguard, EAC, BattlEye) просто игнорируются
            s_lastBoostedPid = 0;
        }
    }

    void ProcessOptimizer::RestoreProcessPriorities() {
        std::lock_guard<std::mutex> lock(s_mutex);
        if (s_lastBoostedPid != 0) {
            HANDLE hProc = OpenProcess(PROCESS_SET_INFORMATION, FALSE, s_lastBoostedPid);
            if (hProc) {
                SetPriorityClass(hProc, NORMAL_PRIORITY_CLASS);
                CloseHandle(hProc);
            }
            s_lastBoostedPid = 0;
        }
    }

}
